/*** HELP START ***//**
  @file
  @brief Returns the type of the format
  @details
  Returns the type, eg DATE / DATETIME / TIME (based on hard-coded lookup)
  else CHAR / NUM.  The lookup lists live in mf_dttmfmts.sas, which is also
  usable directly in open code.

  This macro may be extended in the future to support custom formats - this
  would necessitate a call to `dosubl()` for running a proc format with cntlout.

  The function itself takes the following (positional) parameters:

  | PARAMETER | DESCRIPTION |
  |---|---|
  |fmtnm| Format name to be tested.  Can be with or without the w.d extension.|

  Usage:

      %mcf_getfmttype()

      data _null_;
        fmt1=mcf_getfmttype('DATE9.');
        fmt2=mcf_getfmttype('DATETIME');
        put (fmt:)(=);
      run;
      %put fmt3=%sysfunc(mcf_getfmttype(TIME9.));

  Returns:

  > fmt1=DATE fmt2=DATETIME
  > fmt3=TIME

  @param [out] wrap= (YES) Choose NO to omit the proc fcmp wrapper.
  @param [out] lib= (work) The output library in which to create the catalog.
  @param [out] cat= (sasjs) The output catalog in which to create the package.
  @param [out] pkg= (utils) The output package in which to create the function.
    Uses a 3 part format:  libref.catalog.package

  <h4> SAS Macros </h4>
  @li mcf_init.sas
  @li mf_dttmfmts.sas

  <h4> Related Programs </h4>
  @li mcf_getfmttype.test.sas
  @li mp_init.sas

  @todo "Custom Format Lookups" To enable site-specific formats, make
  use of a set of SASJS_FMTLIST_(DATATYPE) global variables.

**//*** HELP END ***/

%macro mcf_getfmttype(wrap=YES
  ,lib=WORK
  ,cat=SASJS
  ,pkg=UTILS
)/*/STORE SOURCE*/;
%local i var cmpval found;

%if %mcf_init(mcf_getfmttype)=1 %then %return;

%if &wrap=YES  %then %do;
  proc fcmp outlib=&lib..&cat..&pkg;
%end;

function mcf_getfmttype(fmtnm $) $8;
  if substr(fmtnm,1,1)='$' then return('CHAR');
  else do;
    /* extract NAME */
    length fmt $32;
    fmt=scan(fmtnm,1,'.');
    do while (
      substr(fmt,length(fmt),1) in ('1','2','3','4','5','6','7','8','9','0')
      );
      if length(fmt)=1 then fmt='W';
      else fmt=substr(fmt,1,length(fmt)-1);
    end;

    /* apply lookups - the format lists live in mf_dttmfmts.sas */
    if cats(fmt) in (%mf_dttmfmts(DATETIME)) then return('DATETIME');
    else if cats(fmt) in (%mf_dttmfmts(DATE)) then return('DATE');
    else if cats(fmt) in (%mf_dttmfmts(TIME)) then return('TIME');
    else return('NUM');
  end;
endsub;

%if &wrap=YES %then %do;
  quit;
%end;

/* insert the CMPLIB if not already there */
%let cmpval=%sysfunc(getoption(cmplib));
%let found=0;
%do i=1 %to %sysfunc(countw(&cmpval,%str( %(%))));
  %let var=%scan(&cmpval,&i,%str( %(%)));
  %if &var=&lib..&cat %then %let found=1;
%end;
%if &found=0 %then %do;
  options insert=(CMPLIB=(&lib..&cat));
%end;

%mend mcf_getfmttype;
