filename P6289AE9 list;
 %put NOTE- ;
 %put NOTE: Help for package SASjsCore, version 5.2.2, license MIT;
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-08-25T01:10:00; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- *** START ***;
%let ls_tmp     = %sysfunc(getoption(ls));         
%let ps_tmp     = %sysfunc(getoption(ps));         
%let notes_tmp  = %sysfunc(getoption(notes));      
%let source_tmp = %sysfunc(getoption(source));     
options ls = MAX ps = MAX nonotes nosource;        
%include P6289AE9(packagemetadata.sas) / nosource2; 
data _null_;                                                               
  if strip(symget("helpKeyword")) = " " then                               
    do until (EOF);                                                        
      infile P6289AE9(description.sas) end = EOF;                
      input;                                                               
      if upcase(strip(_infile_)) =: "DESCRIPTION END:"   then printer = 0; 
      if printer then put "| " _infile_;                                   
      if upcase(strip(_infile_)) =: "DESCRIPTION START:" then printer = 1; 
    end;                                                                   
  else stop;                                                               
  put ; put "  Package contains: "; 
put @5 "1." @10 "macros " @21 "mf_abort ";
put @5 "2." @10 "macros " @21 "mf_dedup ";
put @5 "3." @10 "macros " @21 "mf_deletefile ";
put @5 "4." @10 "macros " @21 "mf_existds ";
put @5 "5." @10 "macros " @21 "mf_existfeature ";
put @5 "6." @10 "macros " @21 "mf_existfileref ";
put @5 "7." @10 "macros " @21 "mf_existfunction ";
put @5 "8." @10 "macros " @21 "mf_existvar ";
put @5 "9." @10 "macros " @21 "mf_existvarlist ";
put @5 "10." @10 "macros " @21 "mf_fmtdttm ";
put @5 "11." @10 "macros " @21 "mf_getapploc ";
put @5 "12." @10 "macros " @21 "mf_getattrc ";
put @5 "13." @10 "macros " @21 "mf_getattrn ";
put @5 "14." @10 "macros " @21 "mf_getengine ";
put @5 "15." @10 "macros " @21 "mf_getfilesize ";
put @5 "16." @10 "macros " @21 "mf_getfmtlist ";
put @5 "17." @10 "macros " @21 "mf_getfmtname ";
put @5 "18." @10 "macros " @21 "mf_getgitbranch ";
put @5 "19." @10 "macros " @21 "mf_getkeyvalue ";
put @5 "20." @10 "macros " @21 "mf_getplatform ";
put @5 "21." @10 "macros " @21 "mf_getquotedstr ";
put @5 "22." @10 "macros " @21 "mf_getschema ";
put @5 "23." @10 "macros " @21 "mf_getuniquefileref ";
put @5 "24." @10 "macros " @21 "mf_getuniquelibref ";
put @5 "25." @10 "macros " @21 "mf_getuniquename ";
put @5 "26." @10 "macros " @21 "mf_getuser ";
put @5 "27." @10 "macros " @21 "mf_getvalue ";
put @5 "28." @10 "macros " @21 "mf_getvarcount ";
put @5 "29." @10 "macros " @21 "mf_getvarformat ";
put @5 "30." @10 "macros " @21 "mf_getvarlen ";
put @5 "31." @10 "macros " @21 "mf_getvarlist ";
put @5 "32." @10 "macros " @21 "mf_getvarnum ";
put @5 "33." @10 "macros " @21 "mf_getvartype ";
put @5 "34." @10 "macros " @21 "mf_getxengine ";
put @5 "35." @10 "macros " @21 "mf_increment ";
put @5 "36." @10 "macros " @21 "mf_isblank ";
put @5 "37." @10 "macros " @21 "mf_isdir ";
put @5 "38." @10 "macros " @21 "mf_isint ";
put @5 "39." @10 "macros " @21 "mf_islibds ";
put @5 "40." @10 "macros " @21 "mf_loc ";
put @5 "41." @10 "macros " @21 "mf_mimetype ";
put @5 "42." @10 "macros " @21 "mf_mkdir ";
put @5 "43." @10 "macros " @21 "mf_mval ";
put @5 "44." @10 "macros " @21 "mf_nobs ";
put @5 "45." @10 "macros " @21 "mf_readfile ";
put @5 "46." @10 "macros " @21 "mf_trimstr ";
put @5 "47." @10 "macros " @21 "mf_uid ";
put @5 "48." @10 "macros " @21 "mf_verifymacvars ";
put @5 "49." @10 "macros " @21 "mf_wordsinstr1andstr2 ";
put @5 "50." @10 "macros " @21 "mf_wordsinstr1butnotstr2 ";
put @5 "51." @10 "macros " @21 "mf_writefile ";
put @5 "52." @10 "macros " @21 "mp_abort ";
put @5 "53." @10 "macros " @21 "mp_aligndecimal ";
put @5 "54." @10 "macros " @21 "mp_appendfile ";
put @5 "55." @10 "macros " @21 "mp_applyformats ";
put @5 "56." @10 "macros " @21 "mp_assert ";
put @5 "57." @10 "macros " @21 "mp_assertcols ";
put @5 "58." @10 "macros " @21 "mp_assertcolvals ";
put @5 "59." @10 "macros " @21 "mp_assertdsobs ";
put @5 "60." @10 "macros " @21 "mp_assertscope ";
put @5 "61." @10 "macros " @21 "mp_base64copy ";
put @5 "62." @10 "macros " @21 "mp_binarycopy ";
put @5 "63." @10 "macros " @21 "mp_chop ";
put @5 "64." @10 "macros " @21 "mp_cleancsv ";
put @5 "65." @10 "macros " @21 "mp_cntlout ";
put @5 "66." @10 "macros " @21 "mp_copyfolder ";
put @5 "67." @10 "macros " @21 "mp_coretable ";
put @5 "68." @10 "macros " @21 "mp_createconstraints ";
put @5 "69." @10 "macros " @21 "mp_createwebservice ";
put @5 "70." @10 "macros " @21 "mp_csv2ds ";
put @5 "71." @10 "macros " @21 "mp_deleteconstraints ";
put @5 "72." @10 "macros " @21 "mp_deletefolder ";
put @5 "73." @10 "macros " @21 "mp_dictionary ";
put @5 "74." @10 "macros " @21 "mp_dirlist ";
put @5 "75." @10 "macros " @21 "mp_distinctfmtvalues ";
put @5 "76." @10 "macros " @21 "mp_dropmembers ";
put @5 "77." @10 "macros " @21 "mp_ds2cards ";
put @5 "78." @10 "macros " @21 "mp_ds2csv ";
put @5 "79." @10 "macros " @21 "mp_ds2ddl ";
put @5 "80." @10 "macros " @21 "mp_ds2fmtds ";
put @5 "81." @10 "macros " @21 "mp_ds2inserts ";
put @5 "82." @10 "macros " @21 "mp_ds2md ";
put @5 "83." @10 "macros " @21 "mp_ds2squeeze ";
put @5 "84." @10 "macros " @21 "mp_dsmeta ";
put @5 "85." @10 "macros " @21 "mp_execute ";
put @5 "86." @10 "macros " @21 "mp_filtercheck ";
put @5 "87." @10 "macros " @21 "mp_filtergenerate ";
put @5 "88." @10 "macros " @21 "mp_filterstore ";
put @5 "89." @10 "macros " @21 "mp_filtervalidate ";
put @5 "90." @10 "macros " @21 "mp_getcols ";
put @5 "91." @10 "macros " @21 "mp_getconstraints ";
put @5 "92." @10 "macros " @21 "mp_getdbml ";
put @5 "93." @10 "macros " @21 "mp_getddl ";
put @5 "94." @10 "macros " @21 "mp_getformats ";
put @5 "95." @10 "macros " @21 "mp_getmaxvarlengths ";
put @5 "96." @10 "macros " @21 "mp_getpk ";
put @5 "97." @10 "macros " @21 "mp_gitadd ";
put @5 "98." @10 "macros " @21 "mp_gitlog ";
put @5 "99." @10 "macros " @21 "mp_gitreleaseinfo ";
put @5 "100." @10 "macros " @21 "mp_gitstatus ";
put @5 "101." @10 "macros " @21 "mp_gsubfile ";
put @5 "102." @10 "macros " @21 "mp_guesspk ";
put @5 "103." @10 "macros " @21 "mp_hashdataset ";
put @5 "104." @10 "macros " @21 "mp_hashdirectory ";
put @5 "105." @10 "macros " @21 "mp_include ";
put @5 "106." @10 "macros " @21 "mp_init ";
put @5 "107." @10 "macros " @21 "mp_jsonout ";
put @5 "108." @10 "macros " @21 "mp_lib2cards ";
put @5 "109." @10 "macros " @21 "mp_lib2inserts ";
put @5 "110." @10 "macros " @21 "mp_loadformat ";
put @5 "111." @10 "macros " @21 "mp_lockanytable ";
put @5 "112." @10 "macros " @21 "mp_lockfilecheck ";
put @5 "113." @10 "macros " @21 "mp_makedata ";
put @5 "114." @10 "macros " @21 "mp_md5 ";
put @5 "115." @10 "macros " @21 "mp_perflog ";
put @5 "116." @10 "macros " @21 "mp_prevobs ";
put @5 "117." @10 "macros " @21 "mp_recursivejoin ";
put @5 "118." @10 "macros " @21 "mp_replace ";
put @5 "119." @10 "macros " @21 "mp_reseterror ";
put @5 "120." @10 "macros " @21 "mp_resetoption ";
put @5 "121." @10 "macros " @21 "mp_retainedkey ";
put @5 "122." @10 "macros " @21 "mp_rowhash ";
put @5 "123." @10 "macros " @21 "mp_runddl ";
put @5 "124." @10 "macros " @21 "mp_searchcols ";
put @5 "125." @10 "macros " @21 "mp_searchdata ";
put @5 "126." @10 "macros " @21 "mp_setkeyvalue ";
put @5 "127." @10 "macros " @21 "mp_sortinplace ";
put @5 "128." @10 "macros " @21 "mp_stackdiffs ";
put @5 "129." @10 "macros " @21 "mp_storediffs ";
put @5 "130." @10 "macros " @21 "mp_stprequests ";
put @5 "131." @10 "macros " @21 "mp_streamfile ";
put @5 "132." @10 "macros " @21 "mp_stripdiffs ";
put @5 "133." @10 "macros " @21 "mp_testjob ";
put @5 "134." @10 "macros " @21 "mp_testservice ";
put @5 "135." @10 "macros " @21 "mp_testwritespeedlibrary ";
put @5 "136." @10 "macros " @21 "mp_tree ";
put @5 "137." @10 "macros " @21 "mp_unzip ";
put @5 "138." @10 "macros " @21 "mp_updatevarlength ";
put @5 "139." @10 "macros " @21 "mp_validatecol ";
put @5 "140." @10 "macros " @21 "mp_wait4file ";
put @5 "141." @10 "macros " @21 "mp_webin ";
put @5 "142." @10 "macros " @21 "mp_zip ";
put @5 "143." @10 "macros " @21 "mddl_dc_difftable ";
put @5 "144." @10 "macros " @21 "mddl_dc_filterdetail ";
put @5 "145." @10 "macros " @21 "mddl_dc_filtersummary ";
put @5 "146." @10 "macros " @21 "mddl_dc_locktable ";
put @5 "147." @10 "macros " @21 "mddl_dc_maxkeytable ";
put @5 "148." @10 "macros " @21 "mddl_sas_cntlout ";
put @5 "149." @10 "macros " @21 "mcf_getfmttype ";
put @5 "150." @10 "macros " @21 "mcf_init ";
put @5 "151." @10 "macros " @21 "mcf_length ";
put @5 "152." @10 "macros " @21 "mcf_string2file ";
put @5 "153." @10 "macros " @21 "ml_gsubfile ";
put @5 "154." @10 "macros " @21 "ml_json ";
put @5 "155." @10 "macros " @21 "mm_adduser2group ";
put @5 "156." @10 "macros " @21 "mm_assigndirectlib ";
put @5 "157." @10 "macros " @21 "mm_assignlib ";
put @5 "158." @10 "macros " @21 "mm_createapplication ";
put @5 "159." @10 "macros " @21 "mm_createdataset ";
put @5 "160." @10 "macros " @21 "mm_createdocument ";
put @5 "161." @10 "macros " @21 "mm_createfolder ";
put @5 "162." @10 "macros " @21 "mm_createlibrary ";
put @5 "163." @10 "macros " @21 "mm_createstp ";
put @5 "164." @10 "macros " @21 "mm_createwebservice ";
put @5 "165." @10 "macros " @21 "mm_deletedocument ";
put @5 "166." @10 "macros " @21 "mm_deletelibrary ";
put @5 "167." @10 "macros " @21 "mm_deletestp ";
put @5 "168." @10 "macros " @21 "mm_getauthinfo ";
put @5 "169." @10 "macros " @21 "mm_getcols ";
put @5 "170." @10 "macros " @21 "mm_getdetails ";
put @5 "171." @10 "macros " @21 "mm_getdirectories ";
put @5 "172." @10 "macros " @21 "mm_getdocument ";
put @5 "173." @10 "macros " @21 "mm_getfoldermembers ";
put @5 "174." @10 "macros " @21 "mm_getfoldertree ";
put @5 "175." @10 "macros " @21 "mm_getgroupmembers ";
put @5 "176." @10 "macros " @21 "mm_getgroups ";
put @5 "177." @10 "macros " @21 "mm_getlibmetadiffs ";
put @5 "178." @10 "macros " @21 "mm_getlibs ";
put @5 "179." @10 "macros " @21 "mm_getobjects ";
put @5 "180." @10 "macros " @21 "mm_getpublictypes ";
put @5 "181." @10 "macros " @21 "mm_getrepos ";
put @5 "182." @10 "macros " @21 "mm_getroles ";
put @5 "183." @10 "macros " @21 "mm_getservercontexts ";
put @5 "184." @10 "macros " @21 "mm_getstpcode ";
put @5 "185." @10 "macros " @21 "mm_getstpinfo ";
put @5 "186." @10 "macros " @21 "mm_getstps ";
put @5 "187." @10 "macros " @21 "mm_gettableid ";
put @5 "188." @10 "macros " @21 "mm_gettables ";
put @5 "189." @10 "macros " @21 "mm_gettree ";
put @5 "190." @10 "macros " @21 "mm_gettypes ";
put @5 "191." @10 "macros " @21 "mm_getusers ";
put @5 "192." @10 "macros " @21 "mm_getwebappsrvprops ";
put @5 "193." @10 "macros " @21 "mm_spkexport ";
put @5 "194." @10 "macros " @21 "mm_tree ";
put @5 "195." @10 "macros " @21 "mm_updateappextension ";
put @5 "196." @10 "macros " @21 "mm_updatedocument ";
put @5 "197." @10 "macros " @21 "mm_updatestpservertype ";
put @5 "198." @10 "macros " @21 "mm_updatestpsourcecode ";
put @5 "199." @10 "macros " @21 "mm_webout ";
put @5 "200." @10 "macros " @21 "mmx_createmetafolder ";
put @5 "201." @10 "macros " @21 "mmx_deletemetafolder ";
put @5 "202." @10 "macros " @21 "mmx_spkexport ";
put @5 "203." @10 "macros " @21 "mfs_httpheader ";
put @5 "204." @10 "macros " @21 "ms_adduser2group ";
put @5 "205." @10 "macros " @21 "ms_createfile ";
put @5 "206." @10 "macros " @21 "ms_creategroup ";
put @5 "207." @10 "macros " @21 "ms_createuser ";
put @5 "208." @10 "macros " @21 "ms_createwebservice ";
put @5 "209." @10 "macros " @21 "ms_deletefile ";
put @5 "210." @10 "macros " @21 "ms_getfile ";
put @5 "211." @10 "macros " @21 "ms_getgroups ";
put @5 "212." @10 "macros " @21 "ms_getusers ";
put @5 "213." @10 "macros " @21 "ms_runstp ";
put @5 "214." @10 "macros " @21 "ms_testservice ";
put @5 "215." @10 "macros " @21 "ms_triggerstp ";
put @5 "216." @10 "macros " @21 "ms_webout ";
put @5 "217." @10 "macros " @21 "mfv_existfile ";
put @5 "218." @10 "macros " @21 "mfv_existfolder ";
put @5 "219." @10 "macros " @21 "mfv_existsashdat ";
put @5 "220." @10 "macros " @21 "mfv_getcaslib ";
put @5 "221." @10 "macros " @21 "mfv_getfolderpath ";
put @5 "222." @10 "macros " @21 "mfv_getpathuri ";
put @5 "223." @10 "macros " @21 "mv_castabload ";
put @5 "224." @10 "macros " @21 "mv_castabsave ";
put @5 "225." @10 "macros " @21 "mv_createfile ";
put @5 "226." @10 "macros " @21 "mv_createfolder ";
put @5 "227." @10 "macros " @21 "mv_createjob ";
put @5 "228." @10 "macros " @21 "mv_createwebservice ";
put @5 "229." @10 "macros " @21 "mv_deletefoldermember ";
put @5 "230." @10 "macros " @21 "mv_deletejes ";
put @5 "231." @10 "macros " @21 "mv_deleteviyafolder ";
put @5 "232." @10 "macros " @21 "mv_getclients ";
put @5 "233." @10 "macros " @21 "mv_getfoldermembers ";
put @5 "234." @10 "macros " @21 "mv_getgroupmembers ";
put @5 "235." @10 "macros " @21 "mv_getgroups ";
put @5 "236." @10 "macros " @21 "mv_getjobcode ";
put @5 "237." @10 "macros " @21 "mv_getjoblog ";
put @5 "238." @10 "macros " @21 "mv_getjobresult ";
put @5 "239." @10 "macros " @21 "mv_getjobstate ";
put @5 "240." @10 "macros " @21 "mv_getusergroups ";
put @5 "241." @10 "macros " @21 "mv_getusers ";
put @5 "242." @10 "macros " @21 "mv_getviyafileextparms ";
put @5 "243." @10 "macros " @21 "mv_jobexecute ";
put @5 "244." @10 "macros " @21 "mv_jobflow ";
put @5 "245." @10 "macros " @21 "mv_jobwaitfor ";
put @5 "246." @10 "macros " @21 "mv_registerclient ";
put @5 "247." @10 "macros " @21 "mv_tokenauth ";
put @5 "248." @10 "macros " @21 "mv_tokenrefresh ";
put @5 "249." @10 "macros " @21 "mv_webout ";
put @5 "250." @10 "macros " @21 "mx_append2pgm ";
put @5 "251." @10 "macros " @21 "mx_createfile ";
put @5 "252." @10 "macros " @21 "mx_createjob ";
put @5 "253." @10 "macros " @21 "mx_createwebservice ";
put @5 "254." @10 "macros " @21 "mx_execute ";
put @5 "255." @10 "macros " @21 "mx_getcode ";
put @5 "256." @10 "macros " @21 "mx_getgroups ";
put @5 "257." @10 "macros " @21 "mx_testservice ";
put " " / @3 "---------------------------------------------------------------------" / " ";
put @3 "*SAS package generated by SAS Package Framework, version `20260727`*";
put @3 '*under `LIN X64`(`Linux`) operating system,*';
put @3 '*using SAS release: `9.04.01M9P06052025`.*';
put " " / @3 "---------------------------------------------------------------------";
run;                                                                      

data _null_;                                                   
  if upcase(strip(symget("helpKeyword"))) = "LICENSE" then     
    do until (EOF);                                            
      infile P6289AE9(license.sas) end = EOF;        
      input;                                                   
      put "| " _infile_;                                       
    end;                                                       
  else stop;                                                   
run;                                                           
data WORK._%sysfunc(datetime(), hex16.)_;                      
infile cards4 dlm = "/";                                       
input @;                                                       
if 0 then output;                                              
length helpKeyword $ 64;                                       
retain helpKeyword "*";                                        
drop helpKeyword;                                              
if _N_ = 1 then helpKeyword = strip(symget("helpKeyword"));    
if FIND(_INFILE_, helpKeyword, "it") or helpKeyword = "*" then 
 do;                                                           
   input (folder order type file fileshort) (: $ 256.);        
   output;                                                     
 end;                                                          
cards4;                                                        
001_macros/001/macros/mf_abort.sas/mf_abort/'%mf_abort()'
001_macros/001/macros/mf_dedup.sas/mf_dedup/'%mf_dedup()'
001_macros/001/macros/mf_deletefile.sas/mf_deletefile/'%mf_deletefile()'
001_macros/001/macros/mf_existds.sas/mf_existds/'%mf_existds()'
001_macros/001/macros/mf_existfeature.sas/mf_existfeature/'%mf_existfeature()'
001_macros/001/macros/mf_existfileref.sas/mf_existfileref/'%mf_existfileref()'
001_macros/001/macros/mf_existfunction.sas/mf_existfunction/'%mf_existfunction()'
001_macros/001/macros/mf_existvar.sas/mf_existvar/'%mf_existvar()'
001_macros/001/macros/mf_existvarlist.sas/mf_existvarlist/'%mf_existvarlist()'
001_macros/001/macros/mf_fmtdttm.sas/mf_fmtdttm/'%mf_fmtdttm()'
001_macros/001/macros/mf_getapploc.sas/mf_getapploc/'%mf_getapploc()'
001_macros/001/macros/mf_getattrc.sas/mf_getattrc/'%mf_getattrc()'
001_macros/001/macros/mf_getattrn.sas/mf_getattrn/'%mf_getattrn()'
001_macros/001/macros/mf_getengine.sas/mf_getengine/'%mf_getengine()'
001_macros/001/macros/mf_getfilesize.sas/mf_getfilesize/'%mf_getfilesize()'
001_macros/001/macros/mf_getfmtlist.sas/mf_getfmtlist/'%mf_getfmtlist()'
001_macros/001/macros/mf_getfmtname.sas/mf_getfmtname/'%mf_getfmtname()'
001_macros/001/macros/mf_getgitbranch.sas/mf_getgitbranch/'%mf_getgitbranch()'
001_macros/001/macros/mf_getkeyvalue.sas/mf_getkeyvalue/'%mf_getkeyvalue()'
001_macros/001/macros/mf_getplatform.sas/mf_getplatform/'%mf_getplatform()'
001_macros/001/macros/mf_getquotedstr.sas/mf_getquotedstr/'%mf_getquotedstr()'
001_macros/001/macros/mf_getschema.sas/mf_getschema/'%mf_getschema()'
001_macros/001/macros/mf_getuniquefileref.sas/mf_getuniquefileref/'%mf_getuniquefileref()'
001_macros/001/macros/mf_getuniquelibref.sas/mf_getuniquelibref/'%mf_getuniquelibref()'
001_macros/001/macros/mf_getuniquename.sas/mf_getuniquename/'%mf_getuniquename()'
001_macros/001/macros/mf_getuser.sas/mf_getuser/'%mf_getuser()'
001_macros/001/macros/mf_getvalue.sas/mf_getvalue/'%mf_getvalue()'
001_macros/001/macros/mf_getvarcount.sas/mf_getvarcount/'%mf_getvarcount()'
001_macros/001/macros/mf_getvarformat.sas/mf_getvarformat/'%mf_getvarformat()'
001_macros/001/macros/mf_getvarlen.sas/mf_getvarlen/'%mf_getvarlen()'
001_macros/001/macros/mf_getvarlist.sas/mf_getvarlist/'%mf_getvarlist()'
001_macros/001/macros/mf_getvarnum.sas/mf_getvarnum/'%mf_getvarnum()'
001_macros/001/macros/mf_getvartype.sas/mf_getvartype/'%mf_getvartype()'
001_macros/001/macros/mf_getxengine.sas/mf_getxengine/'%mf_getxengine()'
001_macros/001/macros/mf_increment.sas/mf_increment/'%mf_increment()'
001_macros/001/macros/mf_isblank.sas/mf_isblank/'%mf_isblank()'
001_macros/001/macros/mf_isdir.sas/mf_isdir/'%mf_isdir()'
001_macros/001/macros/mf_isint.sas/mf_isint/'%mf_isint()'
001_macros/001/macros/mf_islibds.sas/mf_islibds/'%mf_islibds()'
001_macros/001/macros/mf_loc.sas/mf_loc/'%mf_loc()'
001_macros/001/macros/mf_mimetype.sas/mf_mimetype/'%mf_mimetype()'
001_macros/001/macros/mf_mkdir.sas/mf_mkdir/'%mf_mkdir()'
001_macros/001/macros/mf_mval.sas/mf_mval/'%mf_mval()'
001_macros/001/macros/mf_nobs.sas/mf_nobs/'%mf_nobs()'
001_macros/001/macros/mf_readfile.sas/mf_readfile/'%mf_readfile()'
001_macros/001/macros/mf_trimstr.sas/mf_trimstr/'%mf_trimstr()'
001_macros/001/macros/mf_uid.sas/mf_uid/'%mf_uid()'
001_macros/001/macros/mf_verifymacvars.sas/mf_verifymacvars/'%mf_verifymacvars()'
001_macros/001/macros/mf_wordsinstr1andstr2.sas/mf_wordsinstr1andstr2/'%mf_wordsinstr1andstr2()'
001_macros/001/macros/mf_wordsinstr1butnotstr2.sas/mf_wordsinstr1butnotstr2/'%mf_wordsinstr1butnotstr2()'
001_macros/001/macros/mf_writefile.sas/mf_writefile/'%mf_writefile()'
001_macros/001/macros/mp_abort.sas/mp_abort/'%mp_abort()'
001_macros/001/macros/mp_aligndecimal.sas/mp_aligndecimal/'%mp_aligndecimal()'
001_macros/001/macros/mp_appendfile.sas/mp_appendfile/'%mp_appendfile()'
001_macros/001/macros/mp_applyformats.sas/mp_applyformats/'%mp_applyformats()'
001_macros/001/macros/mp_assert.sas/mp_assert/'%mp_assert()'
001_macros/001/macros/mp_assertcols.sas/mp_assertcols/'%mp_assertcols()'
001_macros/001/macros/mp_assertcolvals.sas/mp_assertcolvals/'%mp_assertcolvals()'
001_macros/001/macros/mp_assertdsobs.sas/mp_assertdsobs/'%mp_assertdsobs()'
001_macros/001/macros/mp_assertscope.sas/mp_assertscope/'%mp_assertscope()'
001_macros/001/macros/mp_base64copy.sas/mp_base64copy/'%mp_base64copy()'
001_macros/001/macros/mp_binarycopy.sas/mp_binarycopy/'%mp_binarycopy()'
001_macros/001/macros/mp_chop.sas/mp_chop/'%mp_chop()'
001_macros/001/macros/mp_cleancsv.sas/mp_cleancsv/'%mp_cleancsv()'
001_macros/001/macros/mp_cntlout.sas/mp_cntlout/'%mp_cntlout()'
001_macros/001/macros/mp_copyfolder.sas/mp_copyfolder/'%mp_copyfolder()'
001_macros/001/macros/mp_coretable.sas/mp_coretable/'%mp_coretable()'
001_macros/001/macros/mp_createconstraints.sas/mp_createconstraints/'%mp_createconstraints()'
001_macros/001/macros/mp_createwebservice.sas/mp_createwebservice/'%mp_createwebservice()'
001_macros/001/macros/mp_csv2ds.sas/mp_csv2ds/'%mp_csv2ds()'
001_macros/001/macros/mp_deleteconstraints.sas/mp_deleteconstraints/'%mp_deleteconstraints()'
001_macros/001/macros/mp_deletefolder.sas/mp_deletefolder/'%mp_deletefolder()'
001_macros/001/macros/mp_dictionary.sas/mp_dictionary/'%mp_dictionary()'
001_macros/001/macros/mp_dirlist.sas/mp_dirlist/'%mp_dirlist()'
001_macros/001/macros/mp_distinctfmtvalues.sas/mp_distinctfmtvalues/'%mp_distinctfmtvalues()'
001_macros/001/macros/mp_dropmembers.sas/mp_dropmembers/'%mp_dropmembers()'
001_macros/001/macros/mp_ds2cards.sas/mp_ds2cards/'%mp_ds2cards()'
001_macros/001/macros/mp_ds2csv.sas/mp_ds2csv/'%mp_ds2csv()'
001_macros/001/macros/mp_ds2ddl.sas/mp_ds2ddl/'%mp_ds2ddl()'
001_macros/001/macros/mp_ds2fmtds.sas/mp_ds2fmtds/'%mp_ds2fmtds()'
001_macros/001/macros/mp_ds2inserts.sas/mp_ds2inserts/'%mp_ds2inserts()'
001_macros/001/macros/mp_ds2md.sas/mp_ds2md/'%mp_ds2md()'
001_macros/001/macros/mp_ds2squeeze.sas/mp_ds2squeeze/'%mp_ds2squeeze()'
001_macros/001/macros/mp_dsmeta.sas/mp_dsmeta/'%mp_dsmeta()'
001_macros/001/macros/mp_execute.sas/mp_execute/'%mp_execute()'
001_macros/001/macros/mp_filtercheck.sas/mp_filtercheck/'%mp_filtercheck()'
001_macros/001/macros/mp_filtergenerate.sas/mp_filtergenerate/'%mp_filtergenerate()'
001_macros/001/macros/mp_filterstore.sas/mp_filterstore/'%mp_filterstore()'
001_macros/001/macros/mp_filtervalidate.sas/mp_filtervalidate/'%mp_filtervalidate()'
001_macros/001/macros/mp_getcols.sas/mp_getcols/'%mp_getcols()'
001_macros/001/macros/mp_getconstraints.sas/mp_getconstraints/'%mp_getconstraints()'
001_macros/001/macros/mp_getdbml.sas/mp_getdbml/'%mp_getdbml()'
001_macros/001/macros/mp_getddl.sas/mp_getddl/'%mp_getddl()'
001_macros/001/macros/mp_getformats.sas/mp_getformats/'%mp_getformats()'
001_macros/001/macros/mp_getmaxvarlengths.sas/mp_getmaxvarlengths/'%mp_getmaxvarlengths()'
001_macros/001/macros/mp_getpk.sas/mp_getpk/'%mp_getpk()'
001_macros/001/macros/mp_gitadd.sas/mp_gitadd/'%mp_gitadd()'
001_macros/001/macros/mp_gitlog.sas/mp_gitlog/'%mp_gitlog()'
001_macros/001/macros/mp_gitreleaseinfo.sas/mp_gitreleaseinfo/'%mp_gitreleaseinfo()'
001_macros/001/macros/mp_gitstatus.sas/mp_gitstatus/'%mp_gitstatus()'
001_macros/001/macros/mp_gsubfile.sas/mp_gsubfile/'%mp_gsubfile()'
001_macros/001/macros/mp_guesspk.sas/mp_guesspk/'%mp_guesspk()'
001_macros/001/macros/mp_hashdataset.sas/mp_hashdataset/'%mp_hashdataset()'
001_macros/001/macros/mp_hashdirectory.sas/mp_hashdirectory/'%mp_hashdirectory()'
001_macros/001/macros/mp_include.sas/mp_include/'%mp_include()'
001_macros/001/macros/mp_init.sas/mp_init/'%mp_init()'
001_macros/001/macros/mp_jsonout.sas/mp_jsonout/'%mp_jsonout()'
001_macros/001/macros/mp_lib2cards.sas/mp_lib2cards/'%mp_lib2cards()'
001_macros/001/macros/mp_lib2inserts.sas/mp_lib2inserts/'%mp_lib2inserts()'
001_macros/001/macros/mp_loadformat.sas/mp_loadformat/'%mp_loadformat()'
001_macros/001/macros/mp_lockanytable.sas/mp_lockanytable/'%mp_lockanytable()'
001_macros/001/macros/mp_lockfilecheck.sas/mp_lockfilecheck/'%mp_lockfilecheck()'
001_macros/001/macros/mp_makedata.sas/mp_makedata/'%mp_makedata()'
001_macros/001/macros/mp_md5.sas/mp_md5/'%mp_md5()'
001_macros/001/macros/mp_perflog.sas/mp_perflog/'%mp_perflog()'
001_macros/001/macros/mp_prevobs.sas/mp_prevobs/'%mp_prevobs()'
001_macros/001/macros/mp_recursivejoin.sas/mp_recursivejoin/'%mp_recursivejoin()'
001_macros/001/macros/mp_replace.sas/mp_replace/'%mp_replace()'
001_macros/001/macros/mp_reseterror.sas/mp_reseterror/'%mp_reseterror()'
001_macros/001/macros/mp_resetoption.sas/mp_resetoption/'%mp_resetoption()'
001_macros/001/macros/mp_retainedkey.sas/mp_retainedkey/'%mp_retainedkey()'
001_macros/001/macros/mp_rowhash.sas/mp_rowhash/'%mp_rowhash()'
001_macros/001/macros/mp_runddl.sas/mp_runddl/'%mp_runddl()'
001_macros/001/macros/mp_searchcols.sas/mp_searchcols/'%mp_searchcols()'
001_macros/001/macros/mp_searchdata.sas/mp_searchdata/'%mp_searchdata()'
001_macros/001/macros/mp_setkeyvalue.sas/mp_setkeyvalue/'%mp_setkeyvalue()'
001_macros/001/macros/mp_sortinplace.sas/mp_sortinplace/'%mp_sortinplace()'
001_macros/001/macros/mp_stackdiffs.sas/mp_stackdiffs/'%mp_stackdiffs()'
001_macros/001/macros/mp_storediffs.sas/mp_storediffs/'%mp_storediffs()'
001_macros/001/macros/mp_stprequests.sas/mp_stprequests/'%mp_stprequests()'
001_macros/001/macros/mp_streamfile.sas/mp_streamfile/'%mp_streamfile()'
001_macros/001/macros/mp_stripdiffs.sas/mp_stripdiffs/'%mp_stripdiffs()'
001_macros/001/macros/mp_testjob.sas/mp_testjob/'%mp_testjob()'
001_macros/001/macros/mp_testservice.sas/mp_testservice/'%mp_testservice()'
001_macros/001/macros/mp_testwritespeedlibrary.sas/mp_testwritespeedlibrary/'%mp_testwritespeedlibrary()'
001_macros/001/macros/mp_tree.sas/mp_tree/'%mp_tree()'
001_macros/001/macros/mp_unzip.sas/mp_unzip/'%mp_unzip()'
001_macros/001/macros/mp_updatevarlength.sas/mp_updatevarlength/'%mp_updatevarlength()'
001_macros/001/macros/mp_validatecol.sas/mp_validatecol/'%mp_validatecol()'
001_macros/001/macros/mp_wait4file.sas/mp_wait4file/'%mp_wait4file()'
001_macros/001/macros/mp_webin.sas/mp_webin/'%mp_webin()'
001_macros/001/macros/mp_zip.sas/mp_zip/'%mp_zip()'
002_macros/002/macros/mddl_dc_difftable.sas/mddl_dc_difftable/'%mddl_dc_difftable()'
002_macros/002/macros/mddl_dc_filterdetail.sas/mddl_dc_filterdetail/'%mddl_dc_filterdetail()'
002_macros/002/macros/mddl_dc_filtersummary.sas/mddl_dc_filtersummary/'%mddl_dc_filtersummary()'
002_macros/002/macros/mddl_dc_locktable.sas/mddl_dc_locktable/'%mddl_dc_locktable()'
002_macros/002/macros/mddl_dc_maxkeytable.sas/mddl_dc_maxkeytable/'%mddl_dc_maxkeytable()'
002_macros/002/macros/mddl_sas_cntlout.sas/mddl_sas_cntlout/'%mddl_sas_cntlout()'
003_macros/003/macros/mcf_getfmttype.sas/mcf_getfmttype/'%mcf_getfmttype()'
003_macros/003/macros/mcf_init.sas/mcf_init/'%mcf_init()'
003_macros/003/macros/mcf_length.sas/mcf_length/'%mcf_length()'
003_macros/003/macros/mcf_string2file.sas/mcf_string2file/'%mcf_string2file()'
004_macros/004/macros/ml_gsubfile.sas/ml_gsubfile/'%ml_gsubfile()'
004_macros/004/macros/ml_json.sas/ml_json/'%ml_json()'
005_macros/005/macros/mm_adduser2group.sas/mm_adduser2group/'%mm_adduser2group()'
005_macros/005/macros/mm_assigndirectlib.sas/mm_assigndirectlib/'%mm_assigndirectlib()'
005_macros/005/macros/mm_assignlib.sas/mm_assignlib/'%mm_assignlib()'
005_macros/005/macros/mm_createapplication.sas/mm_createapplication/'%mm_createapplication()'
005_macros/005/macros/mm_createdataset.sas/mm_createdataset/'%mm_createdataset()'
005_macros/005/macros/mm_createdocument.sas/mm_createdocument/'%mm_createdocument()'
005_macros/005/macros/mm_createfolder.sas/mm_createfolder/'%mm_createfolder()'
005_macros/005/macros/mm_createlibrary.sas/mm_createlibrary/'%mm_createlibrary()'
005_macros/005/macros/mm_createstp.sas/mm_createstp/'%mm_createstp()'
005_macros/005/macros/mm_createwebservice.sas/mm_createwebservice/'%mm_createwebservice()'
005_macros/005/macros/mm_deletedocument.sas/mm_deletedocument/'%mm_deletedocument()'
005_macros/005/macros/mm_deletelibrary.sas/mm_deletelibrary/'%mm_deletelibrary()'
005_macros/005/macros/mm_deletestp.sas/mm_deletestp/'%mm_deletestp()'
005_macros/005/macros/mm_getauthinfo.sas/mm_getauthinfo/'%mm_getauthinfo()'
005_macros/005/macros/mm_getcols.sas/mm_getcols/'%mm_getcols()'
005_macros/005/macros/mm_getdetails.sas/mm_getdetails/'%mm_getdetails()'
005_macros/005/macros/mm_getdirectories.sas/mm_getdirectories/'%mm_getdirectories()'
005_macros/005/macros/mm_getdocument.sas/mm_getdocument/'%mm_getdocument()'
005_macros/005/macros/mm_getfoldermembers.sas/mm_getfoldermembers/'%mm_getfoldermembers()'
005_macros/005/macros/mm_getfoldertree.sas/mm_getfoldertree/'%mm_getfoldertree()'
005_macros/005/macros/mm_getgroupmembers.sas/mm_getgroupmembers/'%mm_getgroupmembers()'
005_macros/005/macros/mm_getgroups.sas/mm_getgroups/'%mm_getgroups()'
005_macros/005/macros/mm_getlibmetadiffs.sas/mm_getlibmetadiffs/'%mm_getlibmetadiffs()'
005_macros/005/macros/mm_getlibs.sas/mm_getlibs/'%mm_getlibs()'
005_macros/005/macros/mm_getobjects.sas/mm_getobjects/'%mm_getobjects()'
005_macros/005/macros/mm_getpublictypes.sas/mm_getpublictypes/'%mm_getpublictypes()'
005_macros/005/macros/mm_getrepos.sas/mm_getrepos/'%mm_getrepos()'
005_macros/005/macros/mm_getroles.sas/mm_getroles/'%mm_getroles()'
005_macros/005/macros/mm_getservercontexts.sas/mm_getservercontexts/'%mm_getservercontexts()'
005_macros/005/macros/mm_getstpcode.sas/mm_getstpcode/'%mm_getstpcode()'
005_macros/005/macros/mm_getstpinfo.sas/mm_getstpinfo/'%mm_getstpinfo()'
005_macros/005/macros/mm_getstps.sas/mm_getstps/'%mm_getstps()'
005_macros/005/macros/mm_gettableid.sas/mm_gettableid/'%mm_gettableid()'
005_macros/005/macros/mm_gettables.sas/mm_gettables/'%mm_gettables()'
005_macros/005/macros/mm_gettree.sas/mm_gettree/'%mm_gettree()'
005_macros/005/macros/mm_gettypes.sas/mm_gettypes/'%mm_gettypes()'
005_macros/005/macros/mm_getusers.sas/mm_getusers/'%mm_getusers()'
005_macros/005/macros/mm_getwebappsrvprops.sas/mm_getwebappsrvprops/'%mm_getwebappsrvprops()'
005_macros/005/macros/mm_spkexport.sas/mm_spkexport/'%mm_spkexport()'
005_macros/005/macros/mm_tree.sas/mm_tree/'%mm_tree()'
005_macros/005/macros/mm_updateappextension.sas/mm_updateappextension/'%mm_updateappextension()'
005_macros/005/macros/mm_updatedocument.sas/mm_updatedocument/'%mm_updatedocument()'
005_macros/005/macros/mm_updatestpservertype.sas/mm_updatestpservertype/'%mm_updatestpservertype()'
005_macros/005/macros/mm_updatestpsourcecode.sas/mm_updatestpsourcecode/'%mm_updatestpsourcecode()'
005_macros/005/macros/mm_webout.sas/mm_webout/'%mm_webout()'
006_macros/006/macros/mmx_createmetafolder.sas/mmx_createmetafolder/'%mmx_createmetafolder()'
006_macros/006/macros/mmx_deletemetafolder.sas/mmx_deletemetafolder/'%mmx_deletemetafolder()'
006_macros/006/macros/mmx_spkexport.sas/mmx_spkexport/'%mmx_spkexport()'
007_macros/007/macros/mfs_httpheader.sas/mfs_httpheader/'%mfs_httpheader()'
007_macros/007/macros/ms_adduser2group.sas/ms_adduser2group/'%ms_adduser2group()'
007_macros/007/macros/ms_createfile.sas/ms_createfile/'%ms_createfile()'
007_macros/007/macros/ms_creategroup.sas/ms_creategroup/'%ms_creategroup()'
007_macros/007/macros/ms_createuser.sas/ms_createuser/'%ms_createuser()'
007_macros/007/macros/ms_createwebservice.sas/ms_createwebservice/'%ms_createwebservice()'
007_macros/007/macros/ms_deletefile.sas/ms_deletefile/'%ms_deletefile()'
007_macros/007/macros/ms_getfile.sas/ms_getfile/'%ms_getfile()'
007_macros/007/macros/ms_getgroups.sas/ms_getgroups/'%ms_getgroups()'
007_macros/007/macros/ms_getusers.sas/ms_getusers/'%ms_getusers()'
007_macros/007/macros/ms_runstp.sas/ms_runstp/'%ms_runstp()'
007_macros/007/macros/ms_testservice.sas/ms_testservice/'%ms_testservice()'
007_macros/007/macros/ms_triggerstp.sas/ms_triggerstp/'%ms_triggerstp()'
007_macros/007/macros/ms_webout.sas/ms_webout/'%ms_webout()'
008_macros/008/macros/mfv_existfile.sas/mfv_existfile/'%mfv_existfile()'
008_macros/008/macros/mfv_existfolder.sas/mfv_existfolder/'%mfv_existfolder()'
008_macros/008/macros/mfv_existsashdat.sas/mfv_existsashdat/'%mfv_existsashdat()'
008_macros/008/macros/mfv_getcaslib.sas/mfv_getcaslib/'%mfv_getcaslib()'
008_macros/008/macros/mfv_getfolderpath.sas/mfv_getfolderpath/'%mfv_getfolderpath()'
008_macros/008/macros/mfv_getpathuri.sas/mfv_getpathuri/'%mfv_getpathuri()'
008_macros/008/macros/mv_castabload.sas/mv_castabload/'%mv_castabload()'
008_macros/008/macros/mv_castabsave.sas/mv_castabsave/'%mv_castabsave()'
008_macros/008/macros/mv_createfile.sas/mv_createfile/'%mv_createfile()'
008_macros/008/macros/mv_createfolder.sas/mv_createfolder/'%mv_createfolder()'
008_macros/008/macros/mv_createjob.sas/mv_createjob/'%mv_createjob()'
008_macros/008/macros/mv_createwebservice.sas/mv_createwebservice/'%mv_createwebservice()'
008_macros/008/macros/mv_deletefoldermember.sas/mv_deletefoldermember/'%mv_deletefoldermember()'
008_macros/008/macros/mv_deletejes.sas/mv_deletejes/'%mv_deletejes()'
008_macros/008/macros/mv_deleteviyafolder.sas/mv_deleteviyafolder/'%mv_deleteviyafolder()'
008_macros/008/macros/mv_getclients.sas/mv_getclients/'%mv_getclients()'
008_macros/008/macros/mv_getfoldermembers.sas/mv_getfoldermembers/'%mv_getfoldermembers()'
008_macros/008/macros/mv_getgroupmembers.sas/mv_getgroupmembers/'%mv_getgroupmembers()'
008_macros/008/macros/mv_getgroups.sas/mv_getgroups/'%mv_getgroups()'
008_macros/008/macros/mv_getjobcode.sas/mv_getjobcode/'%mv_getjobcode()'
008_macros/008/macros/mv_getjoblog.sas/mv_getjoblog/'%mv_getjoblog()'
008_macros/008/macros/mv_getjobresult.sas/mv_getjobresult/'%mv_getjobresult()'
008_macros/008/macros/mv_getjobstate.sas/mv_getjobstate/'%mv_getjobstate()'
008_macros/008/macros/mv_getusergroups.sas/mv_getusergroups/'%mv_getusergroups()'
008_macros/008/macros/mv_getusers.sas/mv_getusers/'%mv_getusers()'
008_macros/008/macros/mv_getviyafileextparms.sas/mv_getviyafileextparms/'%mv_getviyafileextparms()'
008_macros/008/macros/mv_jobexecute.sas/mv_jobexecute/'%mv_jobexecute()'
008_macros/008/macros/mv_jobflow.sas/mv_jobflow/'%mv_jobflow()'
008_macros/008/macros/mv_jobwaitfor.sas/mv_jobwaitfor/'%mv_jobwaitfor()'
008_macros/008/macros/mv_registerclient.sas/mv_registerclient/'%mv_registerclient()'
008_macros/008/macros/mv_tokenauth.sas/mv_tokenauth/'%mv_tokenauth()'
008_macros/008/macros/mv_tokenrefresh.sas/mv_tokenrefresh/'%mv_tokenrefresh()'
008_macros/008/macros/mv_webout.sas/mv_webout/'%mv_webout()'
009_macros/009/macros/mx_append2pgm.sas/mx_append2pgm/'%mx_append2pgm()'
009_macros/009/macros/mx_createfile.sas/mx_createfile/'%mx_createfile()'
009_macros/009/macros/mx_createjob.sas/mx_createjob/'%mx_createjob()'
009_macros/009/macros/mx_createwebservice.sas/mx_createwebservice/'%mx_createwebservice()'
009_macros/009/macros/mx_execute.sas/mx_execute/'%mx_execute()'
009_macros/009/macros/mx_getcode.sas/mx_getcode/'%mx_getcode()'
009_macros/009/macros/mx_getgroups.sas/mx_getgroups/'%mx_getgroups()'
009_macros/009/macros/mx_testservice.sas/mx_testservice/'%mx_testservice()'
;;;;
run;

data _null_;                                                                                              
if upcase(strip(symget("helpKeyword"))) in (" " "LICENSE") then do; stop; end;                            
if NOBS = 0 then do; 
put; put ' *> No help info found. Try %helpPackage(packageName,*) to display all.'; put; stop; 
end; 
  do until(EOFDS);                                                                                        
   set WORK._last_ end = EOFDS nobs = NOBS;                                                               
   length memberX $ 1024;                                                                                 
   memberX = cats("_",folder,".",file);                                                                   
   call execute("data _null_;                                                                          ");
   call execute('infile P6289AE9(' || strip(memberX) || ') end = EOF;                        ');
   call execute("    printer = 0;                                                                      ");
   call execute("    do until(EOF);                                                                    ");
   call execute("      input;                                                                          ");
   call execute("      _endhelpline_ = upcase(reverse(strip(_infile_)));                               ");
   call execute("      if 18 <= lengthn(_endhelpline_) AND _endhelpline_                                  
                          =: '/*** DNE PLEH ***/' then printer = 0;                                  ");
   call execute("      if printer then put ""| "" _infile_;                                            ");
   call execute("      _starthelpline_ = upcase(strip(_infile_));                                      ");
   call execute("      if 20 <= lengthn(_starthelpline_) AND _starthelpline_                              
                          =: '/*** HELP START ***/' then printer = 1;                                ");
   call execute("    end;                                                                              ");
   call execute("  put "" "" / "" "";                                                                  ");
   call execute("  stop;                                                                               ");
   call execute("run;                                                                                  ");
   if lowcase(type) in ("data" "lazydata") then                                                           
    do;                                                                                                   
     call execute("title ""Dataset " || strip(fileshort) || " from package &packageName. "";           ");
     if exist(fileshort) then call execute("proc contents data = " || strip(fileshort) || "; run;      ");
     else call execute("data _null_; put ""| Dataset " || strip(fileshort) || " does not exist.""; run;");
     call execute("title;                                                                              ");
    end;                                                                                                  
  end; 
  stop; 
run; 
proc delete data = WORK._last_; 
run; 
data &packageContentDS. _NULL_;                        
 if "&packageContentDS." = " " then stop;              
  infile cards4 dlm = "/";                             
  input (folder order type file fileshort) (: $ 256.); 
  output;                                              
cards4;                                                
001_macros/001/macros/mf_abort.sas/mf_abort
001_macros/001/macros/mf_dedup.sas/mf_dedup
001_macros/001/macros/mf_deletefile.sas/mf_deletefile
001_macros/001/macros/mf_existds.sas/mf_existds
001_macros/001/macros/mf_existfeature.sas/mf_existfeature
001_macros/001/macros/mf_existfileref.sas/mf_existfileref
001_macros/001/macros/mf_existfunction.sas/mf_existfunction
001_macros/001/macros/mf_existvar.sas/mf_existvar
001_macros/001/macros/mf_existvarlist.sas/mf_existvarlist
001_macros/001/macros/mf_fmtdttm.sas/mf_fmtdttm
001_macros/001/macros/mf_getapploc.sas/mf_getapploc
001_macros/001/macros/mf_getattrc.sas/mf_getattrc
001_macros/001/macros/mf_getattrn.sas/mf_getattrn
001_macros/001/macros/mf_getengine.sas/mf_getengine
001_macros/001/macros/mf_getfilesize.sas/mf_getfilesize
001_macros/001/macros/mf_getfmtlist.sas/mf_getfmtlist
001_macros/001/macros/mf_getfmtname.sas/mf_getfmtname
001_macros/001/macros/mf_getgitbranch.sas/mf_getgitbranch
001_macros/001/macros/mf_getkeyvalue.sas/mf_getkeyvalue
001_macros/001/macros/mf_getplatform.sas/mf_getplatform
001_macros/001/macros/mf_getquotedstr.sas/mf_getquotedstr
001_macros/001/macros/mf_getschema.sas/mf_getschema
001_macros/001/macros/mf_getuniquefileref.sas/mf_getuniquefileref
001_macros/001/macros/mf_getuniquelibref.sas/mf_getuniquelibref
001_macros/001/macros/mf_getuniquename.sas/mf_getuniquename
001_macros/001/macros/mf_getuser.sas/mf_getuser
001_macros/001/macros/mf_getvalue.sas/mf_getvalue
001_macros/001/macros/mf_getvarcount.sas/mf_getvarcount
001_macros/001/macros/mf_getvarformat.sas/mf_getvarformat
001_macros/001/macros/mf_getvarlen.sas/mf_getvarlen
001_macros/001/macros/mf_getvarlist.sas/mf_getvarlist
001_macros/001/macros/mf_getvarnum.sas/mf_getvarnum
001_macros/001/macros/mf_getvartype.sas/mf_getvartype
001_macros/001/macros/mf_getxengine.sas/mf_getxengine
001_macros/001/macros/mf_increment.sas/mf_increment
001_macros/001/macros/mf_isblank.sas/mf_isblank
001_macros/001/macros/mf_isdir.sas/mf_isdir
001_macros/001/macros/mf_isint.sas/mf_isint
001_macros/001/macros/mf_islibds.sas/mf_islibds
001_macros/001/macros/mf_loc.sas/mf_loc
001_macros/001/macros/mf_mimetype.sas/mf_mimetype
001_macros/001/macros/mf_mkdir.sas/mf_mkdir
001_macros/001/macros/mf_mval.sas/mf_mval
001_macros/001/macros/mf_nobs.sas/mf_nobs
001_macros/001/macros/mf_readfile.sas/mf_readfile
001_macros/001/macros/mf_trimstr.sas/mf_trimstr
001_macros/001/macros/mf_uid.sas/mf_uid
001_macros/001/macros/mf_verifymacvars.sas/mf_verifymacvars
001_macros/001/macros/mf_wordsinstr1andstr2.sas/mf_wordsinstr1andstr2
001_macros/001/macros/mf_wordsinstr1butnotstr2.sas/mf_wordsinstr1butnotstr2
001_macros/001/macros/mf_writefile.sas/mf_writefile
001_macros/001/macros/mp_abort.sas/mp_abort
001_macros/001/macros/mp_aligndecimal.sas/mp_aligndecimal
001_macros/001/macros/mp_appendfile.sas/mp_appendfile
001_macros/001/macros/mp_applyformats.sas/mp_applyformats
001_macros/001/macros/mp_assert.sas/mp_assert
001_macros/001/macros/mp_assertcols.sas/mp_assertcols
001_macros/001/macros/mp_assertcolvals.sas/mp_assertcolvals
001_macros/001/macros/mp_assertdsobs.sas/mp_assertdsobs
001_macros/001/macros/mp_assertscope.sas/mp_assertscope
001_macros/001/macros/mp_base64copy.sas/mp_base64copy
001_macros/001/macros/mp_binarycopy.sas/mp_binarycopy
001_macros/001/macros/mp_chop.sas/mp_chop
001_macros/001/macros/mp_cleancsv.sas/mp_cleancsv
001_macros/001/macros/mp_cntlout.sas/mp_cntlout
001_macros/001/macros/mp_copyfolder.sas/mp_copyfolder
001_macros/001/macros/mp_coretable.sas/mp_coretable
001_macros/001/macros/mp_createconstraints.sas/mp_createconstraints
001_macros/001/macros/mp_createwebservice.sas/mp_createwebservice
001_macros/001/macros/mp_csv2ds.sas/mp_csv2ds
001_macros/001/macros/mp_deleteconstraints.sas/mp_deleteconstraints
001_macros/001/macros/mp_deletefolder.sas/mp_deletefolder
001_macros/001/macros/mp_dictionary.sas/mp_dictionary
001_macros/001/macros/mp_dirlist.sas/mp_dirlist
001_macros/001/macros/mp_distinctfmtvalues.sas/mp_distinctfmtvalues
001_macros/001/macros/mp_dropmembers.sas/mp_dropmembers
001_macros/001/macros/mp_ds2cards.sas/mp_ds2cards
001_macros/001/macros/mp_ds2csv.sas/mp_ds2csv
001_macros/001/macros/mp_ds2ddl.sas/mp_ds2ddl
001_macros/001/macros/mp_ds2fmtds.sas/mp_ds2fmtds
001_macros/001/macros/mp_ds2inserts.sas/mp_ds2inserts
001_macros/001/macros/mp_ds2md.sas/mp_ds2md
001_macros/001/macros/mp_ds2squeeze.sas/mp_ds2squeeze
001_macros/001/macros/mp_dsmeta.sas/mp_dsmeta
001_macros/001/macros/mp_execute.sas/mp_execute
001_macros/001/macros/mp_filtercheck.sas/mp_filtercheck
001_macros/001/macros/mp_filtergenerate.sas/mp_filtergenerate
001_macros/001/macros/mp_filterstore.sas/mp_filterstore
001_macros/001/macros/mp_filtervalidate.sas/mp_filtervalidate
001_macros/001/macros/mp_getcols.sas/mp_getcols
001_macros/001/macros/mp_getconstraints.sas/mp_getconstraints
001_macros/001/macros/mp_getdbml.sas/mp_getdbml
001_macros/001/macros/mp_getddl.sas/mp_getddl
001_macros/001/macros/mp_getformats.sas/mp_getformats
001_macros/001/macros/mp_getmaxvarlengths.sas/mp_getmaxvarlengths
001_macros/001/macros/mp_getpk.sas/mp_getpk
001_macros/001/macros/mp_gitadd.sas/mp_gitadd
001_macros/001/macros/mp_gitlog.sas/mp_gitlog
001_macros/001/macros/mp_gitreleaseinfo.sas/mp_gitreleaseinfo
001_macros/001/macros/mp_gitstatus.sas/mp_gitstatus
001_macros/001/macros/mp_gsubfile.sas/mp_gsubfile
001_macros/001/macros/mp_guesspk.sas/mp_guesspk
001_macros/001/macros/mp_hashdataset.sas/mp_hashdataset
001_macros/001/macros/mp_hashdirectory.sas/mp_hashdirectory
001_macros/001/macros/mp_include.sas/mp_include
001_macros/001/macros/mp_init.sas/mp_init
001_macros/001/macros/mp_jsonout.sas/mp_jsonout
001_macros/001/macros/mp_lib2cards.sas/mp_lib2cards
001_macros/001/macros/mp_lib2inserts.sas/mp_lib2inserts
001_macros/001/macros/mp_loadformat.sas/mp_loadformat
001_macros/001/macros/mp_lockanytable.sas/mp_lockanytable
001_macros/001/macros/mp_lockfilecheck.sas/mp_lockfilecheck
001_macros/001/macros/mp_makedata.sas/mp_makedata
001_macros/001/macros/mp_md5.sas/mp_md5
001_macros/001/macros/mp_perflog.sas/mp_perflog
001_macros/001/macros/mp_prevobs.sas/mp_prevobs
001_macros/001/macros/mp_recursivejoin.sas/mp_recursivejoin
001_macros/001/macros/mp_replace.sas/mp_replace
001_macros/001/macros/mp_reseterror.sas/mp_reseterror
001_macros/001/macros/mp_resetoption.sas/mp_resetoption
001_macros/001/macros/mp_retainedkey.sas/mp_retainedkey
001_macros/001/macros/mp_rowhash.sas/mp_rowhash
001_macros/001/macros/mp_runddl.sas/mp_runddl
001_macros/001/macros/mp_searchcols.sas/mp_searchcols
001_macros/001/macros/mp_searchdata.sas/mp_searchdata
001_macros/001/macros/mp_setkeyvalue.sas/mp_setkeyvalue
001_macros/001/macros/mp_sortinplace.sas/mp_sortinplace
001_macros/001/macros/mp_stackdiffs.sas/mp_stackdiffs
001_macros/001/macros/mp_storediffs.sas/mp_storediffs
001_macros/001/macros/mp_stprequests.sas/mp_stprequests
001_macros/001/macros/mp_streamfile.sas/mp_streamfile
001_macros/001/macros/mp_stripdiffs.sas/mp_stripdiffs
001_macros/001/macros/mp_testjob.sas/mp_testjob
001_macros/001/macros/mp_testservice.sas/mp_testservice
001_macros/001/macros/mp_testwritespeedlibrary.sas/mp_testwritespeedlibrary
001_macros/001/macros/mp_tree.sas/mp_tree
001_macros/001/macros/mp_unzip.sas/mp_unzip
001_macros/001/macros/mp_updatevarlength.sas/mp_updatevarlength
001_macros/001/macros/mp_validatecol.sas/mp_validatecol
001_macros/001/macros/mp_wait4file.sas/mp_wait4file
001_macros/001/macros/mp_webin.sas/mp_webin
001_macros/001/macros/mp_zip.sas/mp_zip
002_macros/002/macros/mddl_dc_difftable.sas/mddl_dc_difftable
002_macros/002/macros/mddl_dc_filterdetail.sas/mddl_dc_filterdetail
002_macros/002/macros/mddl_dc_filtersummary.sas/mddl_dc_filtersummary
002_macros/002/macros/mddl_dc_locktable.sas/mddl_dc_locktable
002_macros/002/macros/mddl_dc_maxkeytable.sas/mddl_dc_maxkeytable
002_macros/002/macros/mddl_sas_cntlout.sas/mddl_sas_cntlout
003_macros/003/macros/mcf_getfmttype.sas/mcf_getfmttype
003_macros/003/macros/mcf_init.sas/mcf_init
003_macros/003/macros/mcf_length.sas/mcf_length
003_macros/003/macros/mcf_string2file.sas/mcf_string2file
004_macros/004/macros/ml_gsubfile.sas/ml_gsubfile
004_macros/004/macros/ml_json.sas/ml_json
005_macros/005/macros/mm_adduser2group.sas/mm_adduser2group
005_macros/005/macros/mm_assigndirectlib.sas/mm_assigndirectlib
005_macros/005/macros/mm_assignlib.sas/mm_assignlib
005_macros/005/macros/mm_createapplication.sas/mm_createapplication
005_macros/005/macros/mm_createdataset.sas/mm_createdataset
005_macros/005/macros/mm_createdocument.sas/mm_createdocument
005_macros/005/macros/mm_createfolder.sas/mm_createfolder
005_macros/005/macros/mm_createlibrary.sas/mm_createlibrary
005_macros/005/macros/mm_createstp.sas/mm_createstp
005_macros/005/macros/mm_createwebservice.sas/mm_createwebservice
005_macros/005/macros/mm_deletedocument.sas/mm_deletedocument
005_macros/005/macros/mm_deletelibrary.sas/mm_deletelibrary
005_macros/005/macros/mm_deletestp.sas/mm_deletestp
005_macros/005/macros/mm_getauthinfo.sas/mm_getauthinfo
005_macros/005/macros/mm_getcols.sas/mm_getcols
005_macros/005/macros/mm_getdetails.sas/mm_getdetails
005_macros/005/macros/mm_getdirectories.sas/mm_getdirectories
005_macros/005/macros/mm_getdocument.sas/mm_getdocument
005_macros/005/macros/mm_getfoldermembers.sas/mm_getfoldermembers
005_macros/005/macros/mm_getfoldertree.sas/mm_getfoldertree
005_macros/005/macros/mm_getgroupmembers.sas/mm_getgroupmembers
005_macros/005/macros/mm_getgroups.sas/mm_getgroups
005_macros/005/macros/mm_getlibmetadiffs.sas/mm_getlibmetadiffs
005_macros/005/macros/mm_getlibs.sas/mm_getlibs
005_macros/005/macros/mm_getobjects.sas/mm_getobjects
005_macros/005/macros/mm_getpublictypes.sas/mm_getpublictypes
005_macros/005/macros/mm_getrepos.sas/mm_getrepos
005_macros/005/macros/mm_getroles.sas/mm_getroles
005_macros/005/macros/mm_getservercontexts.sas/mm_getservercontexts
005_macros/005/macros/mm_getstpcode.sas/mm_getstpcode
005_macros/005/macros/mm_getstpinfo.sas/mm_getstpinfo
005_macros/005/macros/mm_getstps.sas/mm_getstps
005_macros/005/macros/mm_gettableid.sas/mm_gettableid
005_macros/005/macros/mm_gettables.sas/mm_gettables
005_macros/005/macros/mm_gettree.sas/mm_gettree
005_macros/005/macros/mm_gettypes.sas/mm_gettypes
005_macros/005/macros/mm_getusers.sas/mm_getusers
005_macros/005/macros/mm_getwebappsrvprops.sas/mm_getwebappsrvprops
005_macros/005/macros/mm_spkexport.sas/mm_spkexport
005_macros/005/macros/mm_tree.sas/mm_tree
005_macros/005/macros/mm_updateappextension.sas/mm_updateappextension
005_macros/005/macros/mm_updatedocument.sas/mm_updatedocument
005_macros/005/macros/mm_updatestpservertype.sas/mm_updatestpservertype
005_macros/005/macros/mm_updatestpsourcecode.sas/mm_updatestpsourcecode
005_macros/005/macros/mm_webout.sas/mm_webout
006_macros/006/macros/mmx_createmetafolder.sas/mmx_createmetafolder
006_macros/006/macros/mmx_deletemetafolder.sas/mmx_deletemetafolder
006_macros/006/macros/mmx_spkexport.sas/mmx_spkexport
007_macros/007/macros/mfs_httpheader.sas/mfs_httpheader
007_macros/007/macros/ms_adduser2group.sas/ms_adduser2group
007_macros/007/macros/ms_createfile.sas/ms_createfile
007_macros/007/macros/ms_creategroup.sas/ms_creategroup
007_macros/007/macros/ms_createuser.sas/ms_createuser
007_macros/007/macros/ms_createwebservice.sas/ms_createwebservice
007_macros/007/macros/ms_deletefile.sas/ms_deletefile
007_macros/007/macros/ms_getfile.sas/ms_getfile
007_macros/007/macros/ms_getgroups.sas/ms_getgroups
007_macros/007/macros/ms_getusers.sas/ms_getusers
007_macros/007/macros/ms_runstp.sas/ms_runstp
007_macros/007/macros/ms_testservice.sas/ms_testservice
007_macros/007/macros/ms_triggerstp.sas/ms_triggerstp
007_macros/007/macros/ms_webout.sas/ms_webout
008_macros/008/macros/mfv_existfile.sas/mfv_existfile
008_macros/008/macros/mfv_existfolder.sas/mfv_existfolder
008_macros/008/macros/mfv_existsashdat.sas/mfv_existsashdat
008_macros/008/macros/mfv_getcaslib.sas/mfv_getcaslib
008_macros/008/macros/mfv_getfolderpath.sas/mfv_getfolderpath
008_macros/008/macros/mfv_getpathuri.sas/mfv_getpathuri
008_macros/008/macros/mv_castabload.sas/mv_castabload
008_macros/008/macros/mv_castabsave.sas/mv_castabsave
008_macros/008/macros/mv_createfile.sas/mv_createfile
008_macros/008/macros/mv_createfolder.sas/mv_createfolder
008_macros/008/macros/mv_createjob.sas/mv_createjob
008_macros/008/macros/mv_createwebservice.sas/mv_createwebservice
008_macros/008/macros/mv_deletefoldermember.sas/mv_deletefoldermember
008_macros/008/macros/mv_deletejes.sas/mv_deletejes
008_macros/008/macros/mv_deleteviyafolder.sas/mv_deleteviyafolder
008_macros/008/macros/mv_getclients.sas/mv_getclients
008_macros/008/macros/mv_getfoldermembers.sas/mv_getfoldermembers
008_macros/008/macros/mv_getgroupmembers.sas/mv_getgroupmembers
008_macros/008/macros/mv_getgroups.sas/mv_getgroups
008_macros/008/macros/mv_getjobcode.sas/mv_getjobcode
008_macros/008/macros/mv_getjoblog.sas/mv_getjoblog
008_macros/008/macros/mv_getjobresult.sas/mv_getjobresult
008_macros/008/macros/mv_getjobstate.sas/mv_getjobstate
008_macros/008/macros/mv_getusergroups.sas/mv_getusergroups
008_macros/008/macros/mv_getusers.sas/mv_getusers
008_macros/008/macros/mv_getviyafileextparms.sas/mv_getviyafileextparms
008_macros/008/macros/mv_jobexecute.sas/mv_jobexecute
008_macros/008/macros/mv_jobflow.sas/mv_jobflow
008_macros/008/macros/mv_jobwaitfor.sas/mv_jobwaitfor
008_macros/008/macros/mv_registerclient.sas/mv_registerclient
008_macros/008/macros/mv_tokenauth.sas/mv_tokenauth
008_macros/008/macros/mv_tokenrefresh.sas/mv_tokenrefresh
008_macros/008/macros/mv_webout.sas/mv_webout
009_macros/009/macros/mx_append2pgm.sas/mx_append2pgm
009_macros/009/macros/mx_createfile.sas/mx_createfile
009_macros/009/macros/mx_createjob.sas/mx_createjob
009_macros/009/macros/mx_createwebservice.sas/mx_createwebservice
009_macros/009/macros/mx_execute.sas/mx_execute
009_macros/009/macros/mx_getcode.sas/mx_getcode
009_macros/009/macros/mx_getgroups.sas/mx_getgroups
009_macros/009/macros/mx_testservice.sas/mx_testservice
;;;;
run;
options ls = &ls_tmp. ps = &ps_tmp. &notes_tmp. &source_tmp.; 
%put NOTE: Help for package SASjsCore, version 5.2.2, license MIT;
%put NOTE- *** END ***;
/* help.sas end */
