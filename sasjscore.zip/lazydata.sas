filename P6289AE9 list;
 %put NOTE- ;
 %put NOTE: Data for package SASjsCore, version 5.2.3, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-09-06T11:24:44; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(SASjsCore) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package SASjsCore, version 5.2.3, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
