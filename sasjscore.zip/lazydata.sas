filename P6289AE9 list;
 %put NOTE- ;
 %put NOTE: Data for package SASjsCore, version 5.2.2, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-08-25T01:10:00; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(SASjsCore) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package SASjsCore, version 5.2.2, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
