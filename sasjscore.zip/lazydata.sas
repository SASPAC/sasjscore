filename P6289AE9 list;
 %put NOTE- ;
 %put NOTE: Data for package SASjsCore, version 5.0.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-08-16T21:20:05; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(SASjsCore) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package SASjsCore, version 5.0.0, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
