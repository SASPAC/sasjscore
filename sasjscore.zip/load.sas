filename P6289AE9 list;

 %put NOTE- ;
 %put NOTE: Loading package SASjsCore, version 4.67.2, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-06-25T16:07:52; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(SASjsCore) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  P6289AE9(packagemetadata.sas) / nosource2; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_abort in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_abort.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_abort)=1, NOTE# Macro mf_abort exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_abort.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_dedup in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_dedup.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_dedup)=1, NOTE# Macro mf_dedup exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_dedup.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_deletefile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_deletefile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_deletefile)=1, NOTE# Macro mf_deletefile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_deletefile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_existds in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_existds.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_existds)=1, NOTE# Macro mf_existds exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_existds.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_existfeature in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_existfeature.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_existfeature)=1, NOTE# Macro mf_existfeature exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_existfeature.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_existfileref in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_existfileref.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_existfileref)=1, NOTE# Macro mf_existfileref exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_existfileref.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_existfunction in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_existfunction.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_existfunction)=1, NOTE# Macro mf_existfunction exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_existfunction.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_existvar in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_existvar.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_existvar)=1, NOTE# Macro mf_existvar exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_existvar.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_existvarlist in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_existvarlist.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_existvarlist)=1, NOTE# Macro mf_existvarlist exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_existvarlist.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_fmtdttm in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_fmtdttm.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_fmtdttm)=1, NOTE# Macro mf_fmtdttm exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_fmtdttm.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getapploc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getapploc.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getapploc)=1, NOTE# Macro mf_getapploc exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getapploc.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getattrc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getattrc.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getattrc)=1, NOTE# Macro mf_getattrc exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getattrc.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getattrn in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getattrn.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getattrn)=1, NOTE# Macro mf_getattrn exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getattrn.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getengine in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getengine.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getengine)=1, NOTE# Macro mf_getengine exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getengine.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getfilesize in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getfilesize.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getfilesize)=1, NOTE# Macro mf_getfilesize exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getfilesize.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getfmtlist in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getfmtlist.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getfmtlist)=1, NOTE# Macro mf_getfmtlist exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getfmtlist.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getfmtname in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getfmtname.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getfmtname)=1, NOTE# Macro mf_getfmtname exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getfmtname.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getgitbranch in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getgitbranch.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getgitbranch)=1, NOTE# Macro mf_getgitbranch exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getgitbranch.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getkeyvalue in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getkeyvalue.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getkeyvalue)=1, NOTE# Macro mf_getkeyvalue exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getkeyvalue.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getplatform in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getplatform.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getplatform)=1, NOTE# Macro mf_getplatform exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getplatform.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getquotedstr in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getquotedstr.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getquotedstr)=1, NOTE# Macro mf_getquotedstr exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getquotedstr.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getschema in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getschema.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getschema)=1, NOTE# Macro mf_getschema exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getschema.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getuniquefileref in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getuniquefileref.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getuniquefileref)=1, NOTE# Macro mf_getuniquefileref exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getuniquefileref.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getuniquelibref in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getuniquelibref.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getuniquelibref)=1, NOTE# Macro mf_getuniquelibref exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getuniquelibref.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getuniquename in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getuniquename.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getuniquename)=1, NOTE# Macro mf_getuniquename exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getuniquename.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getuser in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getuser.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getuser)=1, NOTE# Macro mf_getuser exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getuser.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getvalue in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getvalue.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getvalue)=1, NOTE# Macro mf_getvalue exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getvalue.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getvarcount in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getvarcount.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getvarcount)=1, NOTE# Macro mf_getvarcount exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getvarcount.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getvarformat in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getvarformat.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getvarformat)=1, NOTE# Macro mf_getvarformat exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getvarformat.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getvarlen in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getvarlen.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getvarlen)=1, NOTE# Macro mf_getvarlen exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getvarlen.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getvarlist in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getvarlist.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getvarlist)=1, NOTE# Macro mf_getvarlist exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getvarlist.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getvarnum in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getvarnum.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getvarnum)=1, NOTE# Macro mf_getvarnum exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getvarnum.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getvartype in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getvartype.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getvartype)=1, NOTE# Macro mf_getvartype exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getvartype.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_getxengine in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_getxengine.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_getxengine)=1, NOTE# Macro mf_getxengine exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_getxengine.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_increment in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_increment.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_increment)=1, NOTE# Macro mf_increment exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_increment.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_isblank in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_isblank.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_isblank)=1, NOTE# Macro mf_isblank exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_isblank.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_isdir in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_isdir.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_isdir)=1, NOTE# Macro mf_isdir exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_isdir.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_isint in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_isint.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_isint)=1, NOTE# Macro mf_isint exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_isint.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_islibds in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_islibds.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_islibds)=1, NOTE# Macro mf_islibds exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_islibds.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_loc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_loc.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_loc)=1, NOTE# Macro mf_loc exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_loc.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_mimetype in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_mimetype.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_mimetype)=1, NOTE# Macro mf_mimetype exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_mimetype.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_mkdir in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_mkdir.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_mkdir)=1, NOTE# Macro mf_mkdir exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_mkdir.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_mval in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_mval.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_mval)=1, NOTE# Macro mf_mval exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_mval.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_nobs in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_nobs.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_nobs)=1, NOTE# Macro mf_nobs exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_nobs.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_readfile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_readfile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_readfile)=1, NOTE# Macro mf_readfile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_readfile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_trimstr in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_trimstr.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_trimstr)=1, NOTE# Macro mf_trimstr exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_trimstr.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_uid in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_uid.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_uid)=1, NOTE# Macro mf_uid exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_uid.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_verifymacvars in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_verifymacvars.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_verifymacvars)=1, NOTE# Macro mf_verifymacvars exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_verifymacvars.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_wordsinstr1andstr2 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_wordsinstr1andstr2.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_wordsinstr1andstr2)=1, NOTE# Macro mf_wordsinstr1andstr2 exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_wordsinstr1andstr2.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_wordsinstr1butnotstr2 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_wordsinstr1butnotstr2.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_wordsinstr1butnotstr2)=1, NOTE# Macro mf_wordsinstr1butnotstr2 exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_wordsinstr1butnotstr2.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mf_writefile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mf_writefile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mf_writefile)=1, NOTE# Macro mf_writefile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mf_writefile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_abort in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_abort.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_abort)=1, NOTE# Macro mp_abort exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_abort.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_aligndecimal in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_aligndecimal.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_aligndecimal)=1, NOTE# Macro mp_aligndecimal exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_aligndecimal.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_appendfile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_appendfile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_appendfile)=1, NOTE# Macro mp_appendfile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_appendfile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_applyformats in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_applyformats.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_applyformats)=1, NOTE# Macro mp_applyformats exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_applyformats.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_assert in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_assert.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_assert)=1, NOTE# Macro mp_assert exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_assert.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_assertcols in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_assertcols.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_assertcols)=1, NOTE# Macro mp_assertcols exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_assertcols.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_assertcolvals in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_assertcolvals.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_assertcolvals)=1, NOTE# Macro mp_assertcolvals exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_assertcolvals.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_assertdsobs in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_assertdsobs.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_assertdsobs)=1, NOTE# Macro mp_assertdsobs exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_assertdsobs.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_assertscope in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_assertscope.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_assertscope)=1, NOTE# Macro mp_assertscope exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_assertscope.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_base64copy in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_base64copy.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_base64copy)=1, NOTE# Macro mp_base64copy exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_base64copy.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_binarycopy in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_binarycopy.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_binarycopy)=1, NOTE# Macro mp_binarycopy exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_binarycopy.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_chop in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_chop.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_chop)=1, NOTE# Macro mp_chop exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_chop.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_cleancsv in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_cleancsv.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_cleancsv)=1, NOTE# Macro mp_cleancsv exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_cleancsv.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_cntlout in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_cntlout.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_cntlout)=1, NOTE# Macro mp_cntlout exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_cntlout.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_copyfolder in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_copyfolder.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_copyfolder)=1, NOTE# Macro mp_copyfolder exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_copyfolder.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_coretable in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_coretable.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_coretable)=1, NOTE# Macro mp_coretable exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_coretable.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_createconstraints in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_createconstraints.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_createconstraints)=1, NOTE# Macro mp_createconstraints exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_createconstraints.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_createwebservice in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_createwebservice.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_createwebservice)=1, NOTE# Macro mp_createwebservice exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_createwebservice.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_csv2ds in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_csv2ds.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_csv2ds)=1, NOTE# Macro mp_csv2ds exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_csv2ds.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_deleteconstraints in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_deleteconstraints.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_deleteconstraints)=1, NOTE# Macro mp_deleteconstraints exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_deleteconstraints.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_deletefolder in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_deletefolder.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_deletefolder)=1, NOTE# Macro mp_deletefolder exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_deletefolder.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_dictionary in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_dictionary.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_dictionary)=1, NOTE# Macro mp_dictionary exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_dictionary.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_dirlist in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_dirlist.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_dirlist)=1, NOTE# Macro mp_dirlist exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_dirlist.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_distinctfmtvalues in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_distinctfmtvalues.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_distinctfmtvalues)=1, NOTE# Macro mp_distinctfmtvalues exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_distinctfmtvalues.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_dropmembers in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_dropmembers.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_dropmembers)=1, NOTE# Macro mp_dropmembers exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_dropmembers.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_ds2cards in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_ds2cards.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_ds2cards)=1, NOTE# Macro mp_ds2cards exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_ds2cards.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_ds2csv in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_ds2csv.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_ds2csv)=1, NOTE# Macro mp_ds2csv exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_ds2csv.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_ds2ddl in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_ds2ddl.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_ds2ddl)=1, NOTE# Macro mp_ds2ddl exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_ds2ddl.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_ds2fmtds in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_ds2fmtds.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_ds2fmtds)=1, NOTE# Macro mp_ds2fmtds exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_ds2fmtds.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_ds2inserts in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_ds2inserts.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_ds2inserts)=1, NOTE# Macro mp_ds2inserts exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_ds2inserts.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_ds2md in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_ds2md.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_ds2md)=1, NOTE# Macro mp_ds2md exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_ds2md.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_ds2squeeze in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_ds2squeeze.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_ds2squeeze)=1, NOTE# Macro mp_ds2squeeze exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_ds2squeeze.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_dsmeta in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_dsmeta.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_dsmeta)=1, NOTE# Macro mp_dsmeta exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_dsmeta.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_filtercheck in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_filtercheck.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_filtercheck)=1, NOTE# Macro mp_filtercheck exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_filtercheck.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_filtergenerate in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_filtergenerate.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_filtergenerate)=1, NOTE# Macro mp_filtergenerate exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_filtergenerate.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_filterstore in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_filterstore.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_filterstore)=1, NOTE# Macro mp_filterstore exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_filterstore.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_filtervalidate in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_filtervalidate.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_filtervalidate)=1, NOTE# Macro mp_filtervalidate exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_filtervalidate.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_getcols in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_getcols.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_getcols)=1, NOTE# Macro mp_getcols exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_getcols.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_getconstraints in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_getconstraints.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_getconstraints)=1, NOTE# Macro mp_getconstraints exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_getconstraints.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_getdbml in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_getdbml.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_getdbml)=1, NOTE# Macro mp_getdbml exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_getdbml.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_getddl in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_getddl.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_getddl)=1, NOTE# Macro mp_getddl exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_getddl.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_getformats in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_getformats.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_getformats)=1, NOTE# Macro mp_getformats exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_getformats.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_getmaxvarlengths in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_getmaxvarlengths.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_getmaxvarlengths)=1, NOTE# Macro mp_getmaxvarlengths exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_getmaxvarlengths.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_getpk in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_getpk.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_getpk)=1, NOTE# Macro mp_getpk exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_getpk.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_gitadd in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_gitadd.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_gitadd)=1, NOTE# Macro mp_gitadd exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_gitadd.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_gitlog in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_gitlog.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_gitlog)=1, NOTE# Macro mp_gitlog exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_gitlog.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_gitreleaseinfo in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_gitreleaseinfo.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_gitreleaseinfo)=1, NOTE# Macro mp_gitreleaseinfo exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_gitreleaseinfo.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_gitstatus in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_gitstatus.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_gitstatus)=1, NOTE# Macro mp_gitstatus exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_gitstatus.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_gsubfile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_gsubfile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_gsubfile)=1, NOTE# Macro mp_gsubfile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_gsubfile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_guesspk in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_guesspk.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_guesspk)=1, NOTE# Macro mp_guesspk exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_guesspk.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_hashdataset in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_hashdataset.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_hashdataset)=1, NOTE# Macro mp_hashdataset exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_hashdataset.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_hashdirectory in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_hashdirectory.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_hashdirectory)=1, NOTE# Macro mp_hashdirectory exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_hashdirectory.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_include in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_include.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_include)=1, NOTE# Macro mp_include exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_include.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_init in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_init.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_init)=1, NOTE# Macro mp_init exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_init.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_jsonout in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_jsonout.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_jsonout)=1, NOTE# Macro mp_jsonout exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_jsonout.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_lib2cards in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_lib2cards.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_lib2cards)=1, NOTE# Macro mp_lib2cards exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_lib2cards.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_lib2inserts in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_lib2inserts.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_lib2inserts)=1, NOTE# Macro mp_lib2inserts exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_lib2inserts.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_loadformat in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_loadformat.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_loadformat)=1, NOTE# Macro mp_loadformat exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_loadformat.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_lockanytable in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_lockanytable.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_lockanytable)=1, NOTE# Macro mp_lockanytable exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_lockanytable.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_lockfilecheck in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_lockfilecheck.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_lockfilecheck)=1, NOTE# Macro mp_lockfilecheck exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_lockfilecheck.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_makedata in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_makedata.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_makedata)=1, NOTE# Macro mp_makedata exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_makedata.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_md5 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_md5.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_md5)=1, NOTE# Macro mp_md5 exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_md5.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_perflog in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_perflog.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_perflog)=1, NOTE# Macro mp_perflog exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_perflog.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_prevobs in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_prevobs.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_prevobs)=1, NOTE# Macro mp_prevobs exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_prevobs.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_recursivejoin in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_recursivejoin.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_recursivejoin)=1, NOTE# Macro mp_recursivejoin exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_recursivejoin.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_replace in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_replace.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_replace)=1, NOTE# Macro mp_replace exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_replace.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_reseterror in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_reseterror.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_reseterror)=1, NOTE# Macro mp_reseterror exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_reseterror.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_resetoption in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_resetoption.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_resetoption)=1, NOTE# Macro mp_resetoption exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_resetoption.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_retainedkey in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_retainedkey.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_retainedkey)=1, NOTE# Macro mp_retainedkey exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_retainedkey.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_runddl in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_runddl.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_runddl)=1, NOTE# Macro mp_runddl exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_runddl.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_searchcols in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_searchcols.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_searchcols)=1, NOTE# Macro mp_searchcols exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_searchcols.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_searchdata in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_searchdata.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_searchdata)=1, NOTE# Macro mp_searchdata exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_searchdata.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_setkeyvalue in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_setkeyvalue.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_setkeyvalue)=1, NOTE# Macro mp_setkeyvalue exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_setkeyvalue.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_sortinplace in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_sortinplace.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_sortinplace)=1, NOTE# Macro mp_sortinplace exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_sortinplace.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_stackdiffs in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_stackdiffs.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_stackdiffs)=1, NOTE# Macro mp_stackdiffs exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_stackdiffs.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_storediffs in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_storediffs.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_storediffs)=1, NOTE# Macro mp_storediffs exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_storediffs.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_stprequests in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_stprequests.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_stprequests)=1, NOTE# Macro mp_stprequests exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_stprequests.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_streamfile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_streamfile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_streamfile)=1, NOTE# Macro mp_streamfile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_streamfile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_stripdiffs in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_stripdiffs.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_stripdiffs)=1, NOTE# Macro mp_stripdiffs exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_stripdiffs.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_testjob in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_testjob.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_testjob)=1, NOTE# Macro mp_testjob exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_testjob.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_testservice in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_testservice.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_testservice)=1, NOTE# Macro mp_testservice exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_testservice.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_testwritespeedlibrary in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_testwritespeedlibrary.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_testwritespeedlibrary)=1, NOTE# Macro mp_testwritespeedlibrary exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_testwritespeedlibrary.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_tree in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_tree.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_tree)=1, NOTE# Macro mp_tree exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_tree.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_unzip in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_unzip.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_unzip)=1, NOTE# Macro mp_unzip exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_unzip.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_updatevarlength in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_updatevarlength.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_updatevarlength)=1, NOTE# Macro mp_updatevarlength exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_updatevarlength.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_validatecol in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_validatecol.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_validatecol)=1, NOTE# Macro mp_validatecol exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_validatecol.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_wait4file in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_wait4file.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_wait4file)=1, NOTE# Macro mp_wait4file exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_wait4file.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_webin in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_webin.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_webin)=1, NOTE# Macro mp_webin exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_webin.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mp_zip in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mp_zip.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mp_zip)=1, NOTE# Macro mp_zip exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_001_macros.mp_zip.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mddl_dc_difftable in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mddl_dc_difftable.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mddl_dc_difftable)=1, NOTE# Macro mddl_dc_difftable exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_002_macros.mddl_dc_difftable.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mddl_dc_filterdetail in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mddl_dc_filterdetail.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mddl_dc_filterdetail)=1, NOTE# Macro mddl_dc_filterdetail exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_002_macros.mddl_dc_filterdetail.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mddl_dc_filtersummary in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mddl_dc_filtersummary.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mddl_dc_filtersummary)=1, NOTE# Macro mddl_dc_filtersummary exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_002_macros.mddl_dc_filtersummary.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mddl_dc_locktable in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mddl_dc_locktable.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mddl_dc_locktable)=1, NOTE# Macro mddl_dc_locktable exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_002_macros.mddl_dc_locktable.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mddl_dc_maxkeytable in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mddl_dc_maxkeytable.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mddl_dc_maxkeytable)=1, NOTE# Macro mddl_dc_maxkeytable exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_002_macros.mddl_dc_maxkeytable.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mddl_sas_cntlout in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mddl_sas_cntlout.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mddl_sas_cntlout)=1, NOTE# Macro mddl_sas_cntlout exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_002_macros.mddl_sas_cntlout.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mcf_getfmttype in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mcf_getfmttype.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mcf_getfmttype)=1, NOTE# Macro mcf_getfmttype exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_003_macros.mcf_getfmttype.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mcf_init in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mcf_init.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mcf_init)=1, NOTE# Macro mcf_init exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_003_macros.mcf_init.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mcf_length in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mcf_length.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mcf_length)=1, NOTE# Macro mcf_length exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_003_macros.mcf_length.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mcf_string2file in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mcf_string2file.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mcf_string2file)=1, NOTE# Macro mcf_string2file exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_003_macros.mcf_string2file.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ml_gsubfile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ml_gsubfile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ml_gsubfile)=1, NOTE# Macro ml_gsubfile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_004_macros.ml_gsubfile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ml_json in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ml_json.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ml_json)=1, NOTE# Macro ml_json exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_004_macros.ml_json.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_adduser2group in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_adduser2group.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_adduser2group)=1, NOTE# Macro mm_adduser2group exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_adduser2group.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_assigndirectlib in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_assigndirectlib.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_assigndirectlib)=1, NOTE# Macro mm_assigndirectlib exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_assigndirectlib.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_assignlib in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_assignlib.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_assignlib)=1, NOTE# Macro mm_assignlib exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_assignlib.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_createapplication in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_createapplication.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_createapplication)=1, NOTE# Macro mm_createapplication exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_createapplication.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_createdataset in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_createdataset.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_createdataset)=1, NOTE# Macro mm_createdataset exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_createdataset.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_createdocument in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_createdocument.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_createdocument)=1, NOTE# Macro mm_createdocument exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_createdocument.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_createfolder in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_createfolder.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_createfolder)=1, NOTE# Macro mm_createfolder exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_createfolder.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_createlibrary in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_createlibrary.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_createlibrary)=1, NOTE# Macro mm_createlibrary exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_createlibrary.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_createstp in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_createstp.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_createstp)=1, NOTE# Macro mm_createstp exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_createstp.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_createwebservice in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_createwebservice.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_createwebservice)=1, NOTE# Macro mm_createwebservice exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_createwebservice.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_deletedocument in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_deletedocument.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_deletedocument)=1, NOTE# Macro mm_deletedocument exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_deletedocument.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_deletelibrary in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_deletelibrary.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_deletelibrary)=1, NOTE# Macro mm_deletelibrary exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_deletelibrary.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_deletestp in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_deletestp.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_deletestp)=1, NOTE# Macro mm_deletestp exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_deletestp.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getauthinfo in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getauthinfo.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getauthinfo)=1, NOTE# Macro mm_getauthinfo exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getauthinfo.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getcols in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getcols.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getcols)=1, NOTE# Macro mm_getcols exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getcols.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getdetails in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getdetails.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getdetails)=1, NOTE# Macro mm_getdetails exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getdetails.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getdirectories in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getdirectories.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getdirectories)=1, NOTE# Macro mm_getdirectories exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getdirectories.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getdocument in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getdocument.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getdocument)=1, NOTE# Macro mm_getdocument exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getdocument.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getfoldermembers in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getfoldermembers.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getfoldermembers)=1, NOTE# Macro mm_getfoldermembers exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getfoldermembers.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getfoldertree in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getfoldertree.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getfoldertree)=1, NOTE# Macro mm_getfoldertree exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getfoldertree.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getgroupmembers in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getgroupmembers.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getgroupmembers)=1, NOTE# Macro mm_getgroupmembers exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getgroupmembers.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getgroups in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getgroups.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getgroups)=1, NOTE# Macro mm_getgroups exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getgroups.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getlibmetadiffs in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getlibmetadiffs.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getlibmetadiffs)=1, NOTE# Macro mm_getlibmetadiffs exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getlibmetadiffs.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getlibs in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getlibs.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getlibs)=1, NOTE# Macro mm_getlibs exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getlibs.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getobjects in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getobjects.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getobjects)=1, NOTE# Macro mm_getobjects exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getobjects.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getpublictypes in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getpublictypes.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getpublictypes)=1, NOTE# Macro mm_getpublictypes exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getpublictypes.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getrepos in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getrepos.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getrepos)=1, NOTE# Macro mm_getrepos exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getrepos.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getroles in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getroles.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getroles)=1, NOTE# Macro mm_getroles exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getroles.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getservercontexts in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getservercontexts.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getservercontexts)=1, NOTE# Macro mm_getservercontexts exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getservercontexts.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getstpcode in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getstpcode.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getstpcode)=1, NOTE# Macro mm_getstpcode exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getstpcode.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getstpinfo in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getstpinfo.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getstpinfo)=1, NOTE# Macro mm_getstpinfo exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getstpinfo.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getstps in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getstps.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getstps)=1, NOTE# Macro mm_getstps exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getstps.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_gettableid in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_gettableid.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_gettableid)=1, NOTE# Macro mm_gettableid exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_gettableid.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_gettables in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_gettables.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_gettables)=1, NOTE# Macro mm_gettables exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_gettables.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_gettree in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_gettree.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_gettree)=1, NOTE# Macro mm_gettree exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_gettree.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_gettypes in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_gettypes.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_gettypes)=1, NOTE# Macro mm_gettypes exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_gettypes.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getusers in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getusers.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getusers)=1, NOTE# Macro mm_getusers exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getusers.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_getwebappsrvprops in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_getwebappsrvprops.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_getwebappsrvprops)=1, NOTE# Macro mm_getwebappsrvprops exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_getwebappsrvprops.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_spkexport in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_spkexport.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_spkexport)=1, NOTE# Macro mm_spkexport exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_spkexport.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_tree in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_tree.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_tree)=1, NOTE# Macro mm_tree exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_tree.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_updateappextension in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_updateappextension.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_updateappextension)=1, NOTE# Macro mm_updateappextension exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_updateappextension.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_updatedocument in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_updatedocument.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_updatedocument)=1, NOTE# Macro mm_updatedocument exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_updatedocument.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_updatestpservertype in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_updatestpservertype.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_updatestpservertype)=1, NOTE# Macro mm_updatestpservertype exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_updatestpservertype.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_updatestpsourcecode in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_updatestpsourcecode.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_updatestpsourcecode)=1, NOTE# Macro mm_updatestpsourcecode exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_updatestpsourcecode.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mm_webout in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mm_webout.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mm_webout)=1, NOTE# Macro mm_webout exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_005_macros.mm_webout.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mmx_createmetafolder in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mmx_createmetafolder.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mmx_createmetafolder)=1, NOTE# Macro mmx_createmetafolder exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_006_macros.mmx_createmetafolder.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mmx_deletemetafolder in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mmx_deletemetafolder.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mmx_deletemetafolder)=1, NOTE# Macro mmx_deletemetafolder exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_006_macros.mmx_deletemetafolder.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mmx_spkexport in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mmx_spkexport.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mmx_spkexport)=1, NOTE# Macro mmx_spkexport exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_006_macros.mmx_spkexport.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mfs_httpheader in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mfs_httpheader.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mfs_httpheader)=1, NOTE# Macro mfs_httpheader exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.mfs_httpheader.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_adduser2group in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_adduser2group.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_adduser2group)=1, NOTE# Macro ms_adduser2group exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_adduser2group.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_createfile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_createfile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_createfile)=1, NOTE# Macro ms_createfile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_createfile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_creategroup in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_creategroup.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_creategroup)=1, NOTE# Macro ms_creategroup exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_creategroup.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_createuser in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_createuser.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_createuser)=1, NOTE# Macro ms_createuser exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_createuser.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_createwebservice in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_createwebservice.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_createwebservice)=1, NOTE# Macro ms_createwebservice exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_createwebservice.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_deletefile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_deletefile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_deletefile)=1, NOTE# Macro ms_deletefile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_deletefile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_getfile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_getfile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_getfile)=1, NOTE# Macro ms_getfile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_getfile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_getgroups in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_getgroups.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_getgroups)=1, NOTE# Macro ms_getgroups exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_getgroups.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_getusers in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_getusers.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_getusers)=1, NOTE# Macro ms_getusers exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_getusers.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_runstp in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_runstp.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_runstp)=1, NOTE# Macro ms_runstp exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_runstp.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_testservice in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_testservice.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_testservice)=1, NOTE# Macro ms_testservice exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_testservice.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_triggerstp in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_triggerstp.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_triggerstp)=1, NOTE# Macro ms_triggerstp exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_triggerstp.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ms_webout in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "ms_webout.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ms_webout)=1, NOTE# Macro ms_webout exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_007_macros.ms_webout.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mfv_existfile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mfv_existfile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mfv_existfile)=1, NOTE# Macro mfv_existfile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mfv_existfile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mfv_existfolder in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mfv_existfolder.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mfv_existfolder)=1, NOTE# Macro mfv_existfolder exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mfv_existfolder.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mfv_existsashdat in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mfv_existsashdat.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mfv_existsashdat)=1, NOTE# Macro mfv_existsashdat exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mfv_existsashdat.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mfv_getcaslib in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mfv_getcaslib.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mfv_getcaslib)=1, NOTE# Macro mfv_getcaslib exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mfv_getcaslib.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mfv_getfolderpath in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mfv_getfolderpath.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mfv_getfolderpath)=1, NOTE# Macro mfv_getfolderpath exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mfv_getfolderpath.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mfv_getpathuri in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mfv_getpathuri.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mfv_getpathuri)=1, NOTE# Macro mfv_getpathuri exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mfv_getpathuri.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_castabload in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_castabload.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_castabload)=1, NOTE# Macro mv_castabload exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_castabload.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_castabsave in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_castabsave.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_castabsave)=1, NOTE# Macro mv_castabsave exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_castabsave.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_createfile in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_createfile.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_createfile)=1, NOTE# Macro mv_createfile exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_createfile.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_createfolder in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_createfolder.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_createfolder)=1, NOTE# Macro mv_createfolder exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_createfolder.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_createjob in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_createjob.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_createjob)=1, NOTE# Macro mv_createjob exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_createjob.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_createwebservice in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_createwebservice.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_createwebservice)=1, NOTE# Macro mv_createwebservice exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_createwebservice.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_deletefoldermember in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_deletefoldermember.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_deletefoldermember)=1, NOTE# Macro mv_deletefoldermember exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_deletefoldermember.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_deletejes in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_deletejes.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_deletejes)=1, NOTE# Macro mv_deletejes exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_deletejes.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_deleteviyafolder in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_deleteviyafolder.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_deleteviyafolder)=1, NOTE# Macro mv_deleteviyafolder exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_deleteviyafolder.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getclients in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getclients.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getclients)=1, NOTE# Macro mv_getclients exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getclients.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getfoldermembers in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getfoldermembers.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getfoldermembers)=1, NOTE# Macro mv_getfoldermembers exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getfoldermembers.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getgroupmembers in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getgroupmembers.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getgroupmembers)=1, NOTE# Macro mv_getgroupmembers exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getgroupmembers.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getgroups in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getgroups.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getgroups)=1, NOTE# Macro mv_getgroups exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getgroups.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getjobcode in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getjobcode.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getjobcode)=1, NOTE# Macro mv_getjobcode exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getjobcode.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getjoblog in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getjoblog.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getjoblog)=1, NOTE# Macro mv_getjoblog exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getjoblog.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getjobresult in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getjobresult.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getjobresult)=1, NOTE# Macro mv_getjobresult exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getjobresult.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getjobstate in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getjobstate.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getjobstate)=1, NOTE# Macro mv_getjobstate exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getjobstate.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getusergroups in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getusergroups.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getusergroups)=1, NOTE# Macro mv_getusergroups exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getusergroups.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getusers in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getusers.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getusers)=1, NOTE# Macro mv_getusers exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getusers.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_getviyafileextparms in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_getviyafileextparms.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_getviyafileextparms)=1, NOTE# Macro mv_getviyafileextparms exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_getviyafileextparms.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_jobexecute in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_jobexecute.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_jobexecute)=1, NOTE# Macro mv_jobexecute exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_jobexecute.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_jobflow in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_jobflow.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_jobflow)=1, NOTE# Macro mv_jobflow exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_jobflow.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_jobwaitfor in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_jobwaitfor.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_jobwaitfor)=1, NOTE# Macro mv_jobwaitfor exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_jobwaitfor.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_registerclient in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_registerclient.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_registerclient)=1, NOTE# Macro mv_registerclient exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_registerclient.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_tokenauth in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_tokenauth.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_tokenauth)=1, NOTE# Macro mv_tokenauth exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_tokenauth.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_tokenrefresh in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_tokenrefresh.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_tokenrefresh)=1, NOTE# Macro mv_tokenrefresh exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_tokenrefresh.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mv_webout in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mv_webout.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mv_webout)=1, NOTE# Macro mv_webout exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_008_macros.mv_webout.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mx_append2pgm in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mx_append2pgm.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mx_append2pgm)=1, NOTE# Macro mx_append2pgm exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_009_macros.mx_append2pgm.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mx_createjob in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mx_createjob.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mx_createjob)=1, NOTE# Macro mx_createjob exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_009_macros.mx_createjob.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mx_createwebservice in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mx_createwebservice.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mx_createwebservice)=1, NOTE# Macro mx_createwebservice exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_009_macros.mx_createwebservice.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mx_getcode in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mx_getcode.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mx_getcode)=1, NOTE# Macro mx_getcode exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_009_macros.mx_getcode.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mx_getgroups in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mx_getgroups.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mx_getgroups)=1, NOTE# Macro mx_getgroups exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_009_macros.mx_getgroups.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (mx_testservice in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macros from the file "mx_testservice.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(mx_testservice)=1, NOTE# Macro mx_testservice exist. It will be overwritten by the macro from the SASjsCore package, ));
  %include P6289AE9(_009_macros.mx_testservice.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro SASjsCoreCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for SASjsCore package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `SASjsCoreCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260617.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename P6289AE9 &ZIP. '&path./sasjscore.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename P6289AE9 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

data _null_;
run;
data _null_;
run;
%if (%str(*)=%superq(cherryPick)) %then %do;
proc fcmp outlib = work.SASjsCorefcmp.packagemeta ; 
 function SASjsCoreMETA(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("4.67.2"));
   if m = 'D' then return(strip("2026-06-25T16:07:52"));
   if m = 'A' then return(strip("Allan Bowe"));
   if m = 'M' then return(strip("4GL Ltd"));
   if m = 'T' then return(strip("SAS Macros for Application Development"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-06-25T16:07:52"));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.sasjscorefcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.sasjscorefcmp);)
))
%macro SASjsCoreMETA(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(SASjsCoreMETA&syspbuff.)))%end;
%mend;


%end;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#sasjscore(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'SASjsCore(4.67.2)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'SASjsCore(4.67.2)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'SASjsCore(4.67.2)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] SASjsCore(4.67.2)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package SASjsCore, version 4.67.2, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

