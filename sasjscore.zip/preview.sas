filename P6289AE9 list;
 %put NOTE- ;
 %put NOTE: Preview of the SASjsCore package, version 5.2.2, license MIT;
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-08-25T01:10:00; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- *** START ***;
%let ls_tmp     = %sysfunc(getoption(ls));         
%let ps_tmp     = %sysfunc(getoption(ps));         
%let notes_tmp  = %sysfunc(getoption(notes));      
%let source_tmp = %sysfunc(getoption(source));     
options ls = MAX ps = MAX nonotes nosource;        
%include P6289AE9(packagemetadata.sas) / nosource2; 
data _null_;                                                 
  if strip(symget("helpKeyword")) = " " then                 
    do until (EOF);                                          
      infile P6289AE9(description.sas) end = EOF;  
      input;                                                 
      put _infile_;                                          
    end;                                                     
  else stop;                                                 
run;                                                         
data WORK._%sysfunc(datetime(), hex16.)_;                      
infile cards4 dlm = "/";                                       
input @;                                                       
if 0 then output;                                              
length helpKeyword $ 64;                                       
retain helpKeyword "*";                                        
drop helpKeyword;                                              
if _N_ = 1 then helpKeyword = strip(symget("helpKeyword"));    
if FIND(_INFILE_, helpKeyword, "it") or helpKeyword = "*" then 
 do;                                                           
   input (folder order type file fileshort) (: $ 256.);        
   output;                                                     
 end;                                                          
cards4;                                                        
001_macros/001/macros/mf_abort.sas/mf_abort/'%mf_abort()'
001_macros/001/macros/mf_dedup.sas/mf_dedup/'%mf_dedup()'
001_macros/001/macros/mf_deletefile.sas/mf_deletefile/'%mf_deletefile()'
001_macros/001/macros/mf_existds.sas/mf_existds/'%mf_existds()'
001_macros/001/macros/mf_existfeature.sas/mf_existfeature/'%mf_existfeature()'
001_macros/001/macros/mf_existfileref.sas/mf_existfileref/'%mf_existfileref()'
001_macros/001/macros/mf_existfunction.sas/mf_existfunction/'%mf_existfunction()'
001_macros/001/macros/mf_existvar.sas/mf_existvar/'%mf_existvar()'
001_macros/001/macros/mf_existvarlist.sas/mf_existvarlist/'%mf_existvarlist()'
001_macros/001/macros/mf_fmtdttm.sas/mf_fmtdttm/'%mf_fmtdttm()'
001_macros/001/macros/mf_getapploc.sas/mf_getapploc/'%mf_getapploc()'
001_macros/001/macros/mf_getattrc.sas/mf_getattrc/'%mf_getattrc()'
001_macros/001/macros/mf_getattrn.sas/mf_getattrn/'%mf_getattrn()'
001_macros/001/macros/mf_getengine.sas/mf_getengine/'%mf_getengine()'
001_macros/001/macros/mf_getfilesize.sas/mf_getfilesize/'%mf_getfilesize()'
001_macros/001/macros/mf_getfmtlist.sas/mf_getfmtlist/'%mf_getfmtlist()'
001_macros/001/macros/mf_getfmtname.sas/mf_getfmtname/'%mf_getfmtname()'
001_macros/001/macros/mf_getgitbranch.sas/mf_getgitbranch/'%mf_getgitbranch()'
001_macros/001/macros/mf_getkeyvalue.sas/mf_getkeyvalue/'%mf_getkeyvalue()'
001_macros/001/macros/mf_getplatform.sas/mf_getplatform/'%mf_getplatform()'
001_macros/001/macros/mf_getquotedstr.sas/mf_getquotedstr/'%mf_getquotedstr()'
001_macros/001/macros/mf_getschema.sas/mf_getschema/'%mf_getschema()'
001_macros/001/macros/mf_getuniquefileref.sas/mf_getuniquefileref/'%mf_getuniquefileref()'
001_macros/001/macros/mf_getuniquelibref.sas/mf_getuniquelibref/'%mf_getuniquelibref()'
001_macros/001/macros/mf_getuniquename.sas/mf_getuniquename/'%mf_getuniquename()'
001_macros/001/macros/mf_getuser.sas/mf_getuser/'%mf_getuser()'
001_macros/001/macros/mf_getvalue.sas/mf_getvalue/'%mf_getvalue()'
001_macros/001/macros/mf_getvarcount.sas/mf_getvarcount/'%mf_getvarcount()'
001_macros/001/macros/mf_getvarformat.sas/mf_getvarformat/'%mf_getvarformat()'
001_macros/001/macros/mf_getvarlen.sas/mf_getvarlen/'%mf_getvarlen()'
001_macros/001/macros/mf_getvarlist.sas/mf_getvarlist/'%mf_getvarlist()'
001_macros/001/macros/mf_getvarnum.sas/mf_getvarnum/'%mf_getvarnum()'
001_macros/001/macros/mf_getvartype.sas/mf_getvartype/'%mf_getvartype()'
001_macros/001/macros/mf_getxengine.sas/mf_getxengine/'%mf_getxengine()'
001_macros/001/macros/mf_increment.sas/mf_increment/'%mf_increment()'
001_macros/001/macros/mf_isblank.sas/mf_isblank/'%mf_isblank()'
001_macros/001/macros/mf_isdir.sas/mf_isdir/'%mf_isdir()'
001_macros/001/macros/mf_isint.sas/mf_isint/'%mf_isint()'
001_macros/001/macros/mf_islibds.sas/mf_islibds/'%mf_islibds()'
001_macros/001/macros/mf_loc.sas/mf_loc/'%mf_loc()'
001_macros/001/macros/mf_mimetype.sas/mf_mimetype/'%mf_mimetype()'
001_macros/001/macros/mf_mkdir.sas/mf_mkdir/'%mf_mkdir()'
001_macros/001/macros/mf_mval.sas/mf_mval/'%mf_mval()'
001_macros/001/macros/mf_nobs.sas/mf_nobs/'%mf_nobs()'
001_macros/001/macros/mf_readfile.sas/mf_readfile/'%mf_readfile()'
001_macros/001/macros/mf_trimstr.sas/mf_trimstr/'%mf_trimstr()'
001_macros/001/macros/mf_uid.sas/mf_uid/'%mf_uid()'
001_macros/001/macros/mf_verifymacvars.sas/mf_verifymacvars/'%mf_verifymacvars()'
001_macros/001/macros/mf_wordsinstr1andstr2.sas/mf_wordsinstr1andstr2/'%mf_wordsinstr1andstr2()'
001_macros/001/macros/mf_wordsinstr1butnotstr2.sas/mf_wordsinstr1butnotstr2/'%mf_wordsinstr1butnotstr2()'
001_macros/001/macros/mf_writefile.sas/mf_writefile/'%mf_writefile()'
001_macros/001/macros/mp_abort.sas/mp_abort/'%mp_abort()'
001_macros/001/macros/mp_aligndecimal.sas/mp_aligndecimal/'%mp_aligndecimal()'
001_macros/001/macros/mp_appendfile.sas/mp_appendfile/'%mp_appendfile()'
001_macros/001/macros/mp_applyformats.sas/mp_applyformats/'%mp_applyformats()'
001_macros/001/macros/mp_assert.sas/mp_assert/'%mp_assert()'
001_macros/001/macros/mp_assertcols.sas/mp_assertcols/'%mp_assertcols()'
001_macros/001/macros/mp_assertcolvals.sas/mp_assertcolvals/'%mp_assertcolvals()'
001_macros/001/macros/mp_assertdsobs.sas/mp_assertdsobs/'%mp_assertdsobs()'
001_macros/001/macros/mp_assertscope.sas/mp_assertscope/'%mp_assertscope()'
001_macros/001/macros/mp_base64copy.sas/mp_base64copy/'%mp_base64copy()'
001_macros/001/macros/mp_binarycopy.sas/mp_binarycopy/'%mp_binarycopy()'
001_macros/001/macros/mp_chop.sas/mp_chop/'%mp_chop()'
001_macros/001/macros/mp_cleancsv.sas/mp_cleancsv/'%mp_cleancsv()'
001_macros/001/macros/mp_cntlout.sas/mp_cntlout/'%mp_cntlout()'
001_macros/001/macros/mp_copyfolder.sas/mp_copyfolder/'%mp_copyfolder()'
001_macros/001/macros/mp_coretable.sas/mp_coretable/'%mp_coretable()'
001_macros/001/macros/mp_createconstraints.sas/mp_createconstraints/'%mp_createconstraints()'
001_macros/001/macros/mp_createwebservice.sas/mp_createwebservice/'%mp_createwebservice()'
001_macros/001/macros/mp_csv2ds.sas/mp_csv2ds/'%mp_csv2ds()'
001_macros/001/macros/mp_deleteconstraints.sas/mp_deleteconstraints/'%mp_deleteconstraints()'
001_macros/001/macros/mp_deletefolder.sas/mp_deletefolder/'%mp_deletefolder()'
001_macros/001/macros/mp_dictionary.sas/mp_dictionary/'%mp_dictionary()'
001_macros/001/macros/mp_dirlist.sas/mp_dirlist/'%mp_dirlist()'
001_macros/001/macros/mp_distinctfmtvalues.sas/mp_distinctfmtvalues/'%mp_distinctfmtvalues()'
001_macros/001/macros/mp_dropmembers.sas/mp_dropmembers/'%mp_dropmembers()'
001_macros/001/macros/mp_ds2cards.sas/mp_ds2cards/'%mp_ds2cards()'
001_macros/001/macros/mp_ds2csv.sas/mp_ds2csv/'%mp_ds2csv()'
001_macros/001/macros/mp_ds2ddl.sas/mp_ds2ddl/'%mp_ds2ddl()'
001_macros/001/macros/mp_ds2fmtds.sas/mp_ds2fmtds/'%mp_ds2fmtds()'
001_macros/001/macros/mp_ds2inserts.sas/mp_ds2inserts/'%mp_ds2inserts()'
001_macros/001/macros/mp_ds2md.sas/mp_ds2md/'%mp_ds2md()'
001_macros/001/macros/mp_ds2squeeze.sas/mp_ds2squeeze/'%mp_ds2squeeze()'
001_macros/001/macros/mp_dsmeta.sas/mp_dsmeta/'%mp_dsmeta()'
001_macros/001/macros/mp_execute.sas/mp_execute/'%mp_execute()'
001_macros/001/macros/mp_filtercheck.sas/mp_filtercheck/'%mp_filtercheck()'
001_macros/001/macros/mp_filtergenerate.sas/mp_filtergenerate/'%mp_filtergenerate()'
001_macros/001/macros/mp_filterstore.sas/mp_filterstore/'%mp_filterstore()'
001_macros/001/macros/mp_filtervalidate.sas/mp_filtervalidate/'%mp_filtervalidate()'
001_macros/001/macros/mp_getcols.sas/mp_getcols/'%mp_getcols()'
001_macros/001/macros/mp_getconstraints.sas/mp_getconstraints/'%mp_getconstraints()'
001_macros/001/macros/mp_getdbml.sas/mp_getdbml/'%mp_getdbml()'
001_macros/001/macros/mp_getddl.sas/mp_getddl/'%mp_getddl()'
001_macros/001/macros/mp_getformats.sas/mp_getformats/'%mp_getformats()'
001_macros/001/macros/mp_getmaxvarlengths.sas/mp_getmaxvarlengths/'%mp_getmaxvarlengths()'
001_macros/001/macros/mp_getpk.sas/mp_getpk/'%mp_getpk()'
001_macros/001/macros/mp_gitadd.sas/mp_gitadd/'%mp_gitadd()'
001_macros/001/macros/mp_gitlog.sas/mp_gitlog/'%mp_gitlog()'
001_macros/001/macros/mp_gitreleaseinfo.sas/mp_gitreleaseinfo/'%mp_gitreleaseinfo()'
001_macros/001/macros/mp_gitstatus.sas/mp_gitstatus/'%mp_gitstatus()'
001_macros/001/macros/mp_gsubfile.sas/mp_gsubfile/'%mp_gsubfile()'
001_macros/001/macros/mp_guesspk.sas/mp_guesspk/'%mp_guesspk()'
001_macros/001/macros/mp_hashdataset.sas/mp_hashdataset/'%mp_hashdataset()'
001_macros/001/macros/mp_hashdirectory.sas/mp_hashdirectory/'%mp_hashdirectory()'
001_macros/001/macros/mp_include.sas/mp_include/'%mp_include()'
001_macros/001/macros/mp_init.sas/mp_init/'%mp_init()'
001_macros/001/macros/mp_jsonout.sas/mp_jsonout/'%mp_jsonout()'
001_macros/001/macros/mp_lib2cards.sas/mp_lib2cards/'%mp_lib2cards()'
001_macros/001/macros/mp_lib2inserts.sas/mp_lib2inserts/'%mp_lib2inserts()'
001_macros/001/macros/mp_loadformat.sas/mp_loadformat/'%mp_loadformat()'
001_macros/001/macros/mp_lockanytable.sas/mp_lockanytable/'%mp_lockanytable()'
001_macros/001/macros/mp_lockfilecheck.sas/mp_lockfilecheck/'%mp_lockfilecheck()'
001_macros/001/macros/mp_makedata.sas/mp_makedata/'%mp_makedata()'
001_macros/001/macros/mp_md5.sas/mp_md5/'%mp_md5()'
001_macros/001/macros/mp_perflog.sas/mp_perflog/'%mp_perflog()'
001_macros/001/macros/mp_prevobs.sas/mp_prevobs/'%mp_prevobs()'
001_macros/001/macros/mp_recursivejoin.sas/mp_recursivejoin/'%mp_recursivejoin()'
001_macros/001/macros/mp_replace.sas/mp_replace/'%mp_replace()'
001_macros/001/macros/mp_reseterror.sas/mp_reseterror/'%mp_reseterror()'
001_macros/001/macros/mp_resetoption.sas/mp_resetoption/'%mp_resetoption()'
001_macros/001/macros/mp_retainedkey.sas/mp_retainedkey/'%mp_retainedkey()'
001_macros/001/macros/mp_rowhash.sas/mp_rowhash/'%mp_rowhash()'
001_macros/001/macros/mp_runddl.sas/mp_runddl/'%mp_runddl()'
001_macros/001/macros/mp_searchcols.sas/mp_searchcols/'%mp_searchcols()'
001_macros/001/macros/mp_searchdata.sas/mp_searchdata/'%mp_searchdata()'
001_macros/001/macros/mp_setkeyvalue.sas/mp_setkeyvalue/'%mp_setkeyvalue()'
001_macros/001/macros/mp_sortinplace.sas/mp_sortinplace/'%mp_sortinplace()'
001_macros/001/macros/mp_stackdiffs.sas/mp_stackdiffs/'%mp_stackdiffs()'
001_macros/001/macros/mp_storediffs.sas/mp_storediffs/'%mp_storediffs()'
001_macros/001/macros/mp_stprequests.sas/mp_stprequests/'%mp_stprequests()'
001_macros/001/macros/mp_streamfile.sas/mp_streamfile/'%mp_streamfile()'
001_macros/001/macros/mp_stripdiffs.sas/mp_stripdiffs/'%mp_stripdiffs()'
001_macros/001/macros/mp_testjob.sas/mp_testjob/'%mp_testjob()'
001_macros/001/macros/mp_testservice.sas/mp_testservice/'%mp_testservice()'
001_macros/001/macros/mp_testwritespeedlibrary.sas/mp_testwritespeedlibrary/'%mp_testwritespeedlibrary()'
001_macros/001/macros/mp_tree.sas/mp_tree/'%mp_tree()'
001_macros/001/macros/mp_unzip.sas/mp_unzip/'%mp_unzip()'
001_macros/001/macros/mp_updatevarlength.sas/mp_updatevarlength/'%mp_updatevarlength()'
001_macros/001/macros/mp_validatecol.sas/mp_validatecol/'%mp_validatecol()'
001_macros/001/macros/mp_wait4file.sas/mp_wait4file/'%mp_wait4file()'
001_macros/001/macros/mp_webin.sas/mp_webin/'%mp_webin()'
001_macros/001/macros/mp_zip.sas/mp_zip/'%mp_zip()'
002_macros/002/macros/mddl_dc_difftable.sas/mddl_dc_difftable/'%mddl_dc_difftable()'
002_macros/002/macros/mddl_dc_filterdetail.sas/mddl_dc_filterdetail/'%mddl_dc_filterdetail()'
002_macros/002/macros/mddl_dc_filtersummary.sas/mddl_dc_filtersummary/'%mddl_dc_filtersummary()'
002_macros/002/macros/mddl_dc_locktable.sas/mddl_dc_locktable/'%mddl_dc_locktable()'
002_macros/002/macros/mddl_dc_maxkeytable.sas/mddl_dc_maxkeytable/'%mddl_dc_maxkeytable()'
002_macros/002/macros/mddl_sas_cntlout.sas/mddl_sas_cntlout/'%mddl_sas_cntlout()'
003_macros/003/macros/mcf_getfmttype.sas/mcf_getfmttype/'%mcf_getfmttype()'
003_macros/003/macros/mcf_init.sas/mcf_init/'%mcf_init()'
003_macros/003/macros/mcf_length.sas/mcf_length/'%mcf_length()'
003_macros/003/macros/mcf_string2file.sas/mcf_string2file/'%mcf_string2file()'
004_macros/004/macros/ml_gsubfile.sas/ml_gsubfile/'%ml_gsubfile()'
004_macros/004/macros/ml_json.sas/ml_json/'%ml_json()'
005_macros/005/macros/mm_adduser2group.sas/mm_adduser2group/'%mm_adduser2group()'
005_macros/005/macros/mm_assigndirectlib.sas/mm_assigndirectlib/'%mm_assigndirectlib()'
005_macros/005/macros/mm_assignlib.sas/mm_assignlib/'%mm_assignlib()'
005_macros/005/macros/mm_createapplication.sas/mm_createapplication/'%mm_createapplication()'
005_macros/005/macros/mm_createdataset.sas/mm_createdataset/'%mm_createdataset()'
005_macros/005/macros/mm_createdocument.sas/mm_createdocument/'%mm_createdocument()'
005_macros/005/macros/mm_createfolder.sas/mm_createfolder/'%mm_createfolder()'
005_macros/005/macros/mm_createlibrary.sas/mm_createlibrary/'%mm_createlibrary()'
005_macros/005/macros/mm_createstp.sas/mm_createstp/'%mm_createstp()'
005_macros/005/macros/mm_createwebservice.sas/mm_createwebservice/'%mm_createwebservice()'
005_macros/005/macros/mm_deletedocument.sas/mm_deletedocument/'%mm_deletedocument()'
005_macros/005/macros/mm_deletelibrary.sas/mm_deletelibrary/'%mm_deletelibrary()'
005_macros/005/macros/mm_deletestp.sas/mm_deletestp/'%mm_deletestp()'
005_macros/005/macros/mm_getauthinfo.sas/mm_getauthinfo/'%mm_getauthinfo()'
005_macros/005/macros/mm_getcols.sas/mm_getcols/'%mm_getcols()'
005_macros/005/macros/mm_getdetails.sas/mm_getdetails/'%mm_getdetails()'
005_macros/005/macros/mm_getdirectories.sas/mm_getdirectories/'%mm_getdirectories()'
005_macros/005/macros/mm_getdocument.sas/mm_getdocument/'%mm_getdocument()'
005_macros/005/macros/mm_getfoldermembers.sas/mm_getfoldermembers/'%mm_getfoldermembers()'
005_macros/005/macros/mm_getfoldertree.sas/mm_getfoldertree/'%mm_getfoldertree()'
005_macros/005/macros/mm_getgroupmembers.sas/mm_getgroupmembers/'%mm_getgroupmembers()'
005_macros/005/macros/mm_getgroups.sas/mm_getgroups/'%mm_getgroups()'
005_macros/005/macros/mm_getlibmetadiffs.sas/mm_getlibmetadiffs/'%mm_getlibmetadiffs()'
005_macros/005/macros/mm_getlibs.sas/mm_getlibs/'%mm_getlibs()'
005_macros/005/macros/mm_getobjects.sas/mm_getobjects/'%mm_getobjects()'
005_macros/005/macros/mm_getpublictypes.sas/mm_getpublictypes/'%mm_getpublictypes()'
005_macros/005/macros/mm_getrepos.sas/mm_getrepos/'%mm_getrepos()'
005_macros/005/macros/mm_getroles.sas/mm_getroles/'%mm_getroles()'
005_macros/005/macros/mm_getservercontexts.sas/mm_getservercontexts/'%mm_getservercontexts()'
005_macros/005/macros/mm_getstpcode.sas/mm_getstpcode/'%mm_getstpcode()'
005_macros/005/macros/mm_getstpinfo.sas/mm_getstpinfo/'%mm_getstpinfo()'
005_macros/005/macros/mm_getstps.sas/mm_getstps/'%mm_getstps()'
005_macros/005/macros/mm_gettableid.sas/mm_gettableid/'%mm_gettableid()'
005_macros/005/macros/mm_gettables.sas/mm_gettables/'%mm_gettables()'
005_macros/005/macros/mm_gettree.sas/mm_gettree/'%mm_gettree()'
005_macros/005/macros/mm_gettypes.sas/mm_gettypes/'%mm_gettypes()'
005_macros/005/macros/mm_getusers.sas/mm_getusers/'%mm_getusers()'
005_macros/005/macros/mm_getwebappsrvprops.sas/mm_getwebappsrvprops/'%mm_getwebappsrvprops()'
005_macros/005/macros/mm_spkexport.sas/mm_spkexport/'%mm_spkexport()'
005_macros/005/macros/mm_tree.sas/mm_tree/'%mm_tree()'
005_macros/005/macros/mm_updateappextension.sas/mm_updateappextension/'%mm_updateappextension()'
005_macros/005/macros/mm_updatedocument.sas/mm_updatedocument/'%mm_updatedocument()'
005_macros/005/macros/mm_updatestpservertype.sas/mm_updatestpservertype/'%mm_updatestpservertype()'
005_macros/005/macros/mm_updatestpsourcecode.sas/mm_updatestpsourcecode/'%mm_updatestpsourcecode()'
005_macros/005/macros/mm_webout.sas/mm_webout/'%mm_webout()'
006_macros/006/macros/mmx_createmetafolder.sas/mmx_createmetafolder/'%mmx_createmetafolder()'
006_macros/006/macros/mmx_deletemetafolder.sas/mmx_deletemetafolder/'%mmx_deletemetafolder()'
006_macros/006/macros/mmx_spkexport.sas/mmx_spkexport/'%mmx_spkexport()'
007_macros/007/macros/mfs_httpheader.sas/mfs_httpheader/'%mfs_httpheader()'
007_macros/007/macros/ms_adduser2group.sas/ms_adduser2group/'%ms_adduser2group()'
007_macros/007/macros/ms_createfile.sas/ms_createfile/'%ms_createfile()'
007_macros/007/macros/ms_creategroup.sas/ms_creategroup/'%ms_creategroup()'
007_macros/007/macros/ms_createuser.sas/ms_createuser/'%ms_createuser()'
007_macros/007/macros/ms_createwebservice.sas/ms_createwebservice/'%ms_createwebservice()'
007_macros/007/macros/ms_deletefile.sas/ms_deletefile/'%ms_deletefile()'
007_macros/007/macros/ms_getfile.sas/ms_getfile/'%ms_getfile()'
007_macros/007/macros/ms_getgroups.sas/ms_getgroups/'%ms_getgroups()'
007_macros/007/macros/ms_getusers.sas/ms_getusers/'%ms_getusers()'
007_macros/007/macros/ms_runstp.sas/ms_runstp/'%ms_runstp()'
007_macros/007/macros/ms_testservice.sas/ms_testservice/'%ms_testservice()'
007_macros/007/macros/ms_triggerstp.sas/ms_triggerstp/'%ms_triggerstp()'
007_macros/007/macros/ms_webout.sas/ms_webout/'%ms_webout()'
008_macros/008/macros/mfv_existfile.sas/mfv_existfile/'%mfv_existfile()'
008_macros/008/macros/mfv_existfolder.sas/mfv_existfolder/'%mfv_existfolder()'
008_macros/008/macros/mfv_existsashdat.sas/mfv_existsashdat/'%mfv_existsashdat()'
008_macros/008/macros/mfv_getcaslib.sas/mfv_getcaslib/'%mfv_getcaslib()'
008_macros/008/macros/mfv_getfolderpath.sas/mfv_getfolderpath/'%mfv_getfolderpath()'
008_macros/008/macros/mfv_getpathuri.sas/mfv_getpathuri/'%mfv_getpathuri()'
008_macros/008/macros/mv_castabload.sas/mv_castabload/'%mv_castabload()'
008_macros/008/macros/mv_castabsave.sas/mv_castabsave/'%mv_castabsave()'
008_macros/008/macros/mv_createfile.sas/mv_createfile/'%mv_createfile()'
008_macros/008/macros/mv_createfolder.sas/mv_createfolder/'%mv_createfolder()'
008_macros/008/macros/mv_createjob.sas/mv_createjob/'%mv_createjob()'
008_macros/008/macros/mv_createwebservice.sas/mv_createwebservice/'%mv_createwebservice()'
008_macros/008/macros/mv_deletefoldermember.sas/mv_deletefoldermember/'%mv_deletefoldermember()'
008_macros/008/macros/mv_deletejes.sas/mv_deletejes/'%mv_deletejes()'
008_macros/008/macros/mv_deleteviyafolder.sas/mv_deleteviyafolder/'%mv_deleteviyafolder()'
008_macros/008/macros/mv_getclients.sas/mv_getclients/'%mv_getclients()'
008_macros/008/macros/mv_getfoldermembers.sas/mv_getfoldermembers/'%mv_getfoldermembers()'
008_macros/008/macros/mv_getgroupmembers.sas/mv_getgroupmembers/'%mv_getgroupmembers()'
008_macros/008/macros/mv_getgroups.sas/mv_getgroups/'%mv_getgroups()'
008_macros/008/macros/mv_getjobcode.sas/mv_getjobcode/'%mv_getjobcode()'
008_macros/008/macros/mv_getjoblog.sas/mv_getjoblog/'%mv_getjoblog()'
008_macros/008/macros/mv_getjobresult.sas/mv_getjobresult/'%mv_getjobresult()'
008_macros/008/macros/mv_getjobstate.sas/mv_getjobstate/'%mv_getjobstate()'
008_macros/008/macros/mv_getusergroups.sas/mv_getusergroups/'%mv_getusergroups()'
008_macros/008/macros/mv_getusers.sas/mv_getusers/'%mv_getusers()'
008_macros/008/macros/mv_getviyafileextparms.sas/mv_getviyafileextparms/'%mv_getviyafileextparms()'
008_macros/008/macros/mv_jobexecute.sas/mv_jobexecute/'%mv_jobexecute()'
008_macros/008/macros/mv_jobflow.sas/mv_jobflow/'%mv_jobflow()'
008_macros/008/macros/mv_jobwaitfor.sas/mv_jobwaitfor/'%mv_jobwaitfor()'
008_macros/008/macros/mv_registerclient.sas/mv_registerclient/'%mv_registerclient()'
008_macros/008/macros/mv_tokenauth.sas/mv_tokenauth/'%mv_tokenauth()'
008_macros/008/macros/mv_tokenrefresh.sas/mv_tokenrefresh/'%mv_tokenrefresh()'
008_macros/008/macros/mv_webout.sas/mv_webout/'%mv_webout()'
009_macros/009/macros/mx_append2pgm.sas/mx_append2pgm/'%mx_append2pgm()'
009_macros/009/macros/mx_createfile.sas/mx_createfile/'%mx_createfile()'
009_macros/009/macros/mx_createjob.sas/mx_createjob/'%mx_createjob()'
009_macros/009/macros/mx_createwebservice.sas/mx_createwebservice/'%mx_createwebservice()'
009_macros/009/macros/mx_execute.sas/mx_execute/'%mx_execute()'
009_macros/009/macros/mx_getcode.sas/mx_getcode/'%mx_getcode()'
009_macros/009/macros/mx_getgroups.sas/mx_getgroups/'%mx_getgroups()'
009_macros/009/macros/mx_testservice.sas/mx_testservice/'%mx_testservice()'
;;;;
run;
data _null_;                                                                        
if upcase(strip(symget("helpKeyword"))) in (" " "LICENSE") then do; stop; end;      
if NOBS = 0 then do; 
put; put ' *> No preview. Try %previewPackage(packageName,*) to display all.'; put; stop; 
end; 
  do until(EOFDS);                                                                  
   set WORK._last_ end = EOFDS nobs = NOBS;                                         
   length memberX $ 1024;                                                           
   memberX = cats("_",folder,".",file);                                             
   call execute("data _null_;                                                    ");
   call execute('infile P6289AE9(' || strip(memberX) || ') end = EOF;  ');
   call execute("    do until(EOF);                                              ");
   call execute("      input;                                                    ");
   call execute("      put _infile_;                                             ");
   call execute("    end;                                                        ");
   call execute("  put "" "" / "" "";                                            ");
   call execute("  stop;                                                         ");
   call execute("run;                                                            ");
  end; 
  stop; 
run; 
proc delete data = WORK._last_; 
run; 
options ls = &ls_tmp. ps = &ps_tmp. &notes_tmp. &source_tmp.; 
%put NOTE: Preview of the SASjsCore package, version 5.2.2, license MIT;
%put NOTE- *** END ***;
/* preview.sas end */
