filename P6289AE9 list;
%put NOTE: Unloading package SASjsCore, version 4.68.3, license MIT;
%put NOTE- *** START ***;
proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'SASJSCOREMETA'
   ,'SASJSCOREIML'
   ,'SASJSCORECASLUDF'
   %put NOTE- Element of type macros generated from the file "mf_abort.sas" will be deleted;
   %put NOTE- ;
   ,"MF_ABORT                                                        "
   %put NOTE- Element of type macros generated from the file "mf_dedup.sas" will be deleted;
   %put NOTE- ;
   ,"MF_DEDUP                                                        "
   %put NOTE- Element of type macros generated from the file "mf_deletefile.sas" will be deleted;
   %put NOTE- ;
   ,"MF_DELETEFILE                                                   "
   %put NOTE- Element of type macros generated from the file "mf_existds.sas" will be deleted;
   %put NOTE- ;
   ,"MF_EXISTDS                                                      "
   %put NOTE- Element of type macros generated from the file "mf_existfeature.sas" will be deleted;
   %put NOTE- ;
   ,"MF_EXISTFEATURE                                                 "
   %put NOTE- Element of type macros generated from the file "mf_existfileref.sas" will be deleted;
   %put NOTE- ;
   ,"MF_EXISTFILEREF                                                 "
   %put NOTE- Element of type macros generated from the file "mf_existfunction.sas" will be deleted;
   %put NOTE- ;
   ,"MF_EXISTFUNCTION                                                "
   %put NOTE- Element of type macros generated from the file "mf_existvar.sas" will be deleted;
   %put NOTE- ;
   ,"MF_EXISTVAR                                                     "
   %put NOTE- Element of type macros generated from the file "mf_existvarlist.sas" will be deleted;
   %put NOTE- ;
   ,"MF_EXISTVARLIST                                                 "
   %put NOTE- Element of type macros generated from the file "mf_fmtdttm.sas" will be deleted;
   %put NOTE- ;
   ,"MF_FMTDTTM                                                      "
   %put NOTE- Element of type macros generated from the file "mf_getapploc.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETAPPLOC                                                    "
   %put NOTE- Element of type macros generated from the file "mf_getattrc.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETATTRC                                                     "
   %put NOTE- Element of type macros generated from the file "mf_getattrn.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETATTRN                                                     "
   %put NOTE- Element of type macros generated from the file "mf_getengine.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETENGINE                                                    "
   %put NOTE- Element of type macros generated from the file "mf_getfilesize.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETFILESIZE                                                  "
   %put NOTE- Element of type macros generated from the file "mf_getfmtlist.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETFMTLIST                                                   "
   %put NOTE- Element of type macros generated from the file "mf_getfmtname.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETFMTNAME                                                   "
   %put NOTE- Element of type macros generated from the file "mf_getgitbranch.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETGITBRANCH                                                 "
   %put NOTE- Element of type macros generated from the file "mf_getkeyvalue.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETKEYVALUE                                                  "
   %put NOTE- Element of type macros generated from the file "mf_getplatform.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETPLATFORM                                                  "
   %put NOTE- Element of type macros generated from the file "mf_getquotedstr.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETQUOTEDSTR                                                 "
   %put NOTE- Element of type macros generated from the file "mf_getschema.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETSCHEMA                                                    "
   %put NOTE- Element of type macros generated from the file "mf_getuniquefileref.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETUNIQUEFILEREF                                             "
   %put NOTE- Element of type macros generated from the file "mf_getuniquelibref.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETUNIQUELIBREF                                              "
   %put NOTE- Element of type macros generated from the file "mf_getuniquename.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETUNIQUENAME                                                "
   %put NOTE- Element of type macros generated from the file "mf_getuser.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETUSER                                                      "
   %put NOTE- Element of type macros generated from the file "mf_getvalue.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETVALUE                                                     "
   %put NOTE- Element of type macros generated from the file "mf_getvarcount.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETVARCOUNT                                                  "
   %put NOTE- Element of type macros generated from the file "mf_getvarformat.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETVARFORMAT                                                 "
   %put NOTE- Element of type macros generated from the file "mf_getvarlen.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETVARLEN                                                    "
   %put NOTE- Element of type macros generated from the file "mf_getvarlist.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETVARLIST                                                   "
   %put NOTE- Element of type macros generated from the file "mf_getvarnum.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETVARNUM                                                    "
   %put NOTE- Element of type macros generated from the file "mf_getvartype.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETVARTYPE                                                   "
   %put NOTE- Element of type macros generated from the file "mf_getxengine.sas" will be deleted;
   %put NOTE- ;
   ,"MF_GETXENGINE                                                   "
   %put NOTE- Element of type macros generated from the file "mf_increment.sas" will be deleted;
   %put NOTE- ;
   ,"MF_INCREMENT                                                    "
   %put NOTE- Element of type macros generated from the file "mf_isblank.sas" will be deleted;
   %put NOTE- ;
   ,"MF_ISBLANK                                                      "
   %put NOTE- Element of type macros generated from the file "mf_isdir.sas" will be deleted;
   %put NOTE- ;
   ,"MF_ISDIR                                                        "
   %put NOTE- Element of type macros generated from the file "mf_isint.sas" will be deleted;
   %put NOTE- ;
   ,"MF_ISINT                                                        "
   %put NOTE- Element of type macros generated from the file "mf_islibds.sas" will be deleted;
   %put NOTE- ;
   ,"MF_ISLIBDS                                                      "
   %put NOTE- Element of type macros generated from the file "mf_loc.sas" will be deleted;
   %put NOTE- ;
   ,"MF_LOC                                                          "
   %put NOTE- Element of type macros generated from the file "mf_mimetype.sas" will be deleted;
   %put NOTE- ;
   ,"MF_MIMETYPE                                                     "
   %put NOTE- Element of type macros generated from the file "mf_mkdir.sas" will be deleted;
   %put NOTE- ;
   ,"MF_MKDIR                                                        "
   %put NOTE- Element of type macros generated from the file "mf_mval.sas" will be deleted;
   %put NOTE- ;
   ,"MF_MVAL                                                         "
   %put NOTE- Element of type macros generated from the file "mf_nobs.sas" will be deleted;
   %put NOTE- ;
   ,"MF_NOBS                                                         "
   %put NOTE- Element of type macros generated from the file "mf_readfile.sas" will be deleted;
   %put NOTE- ;
   ,"MF_READFILE                                                     "
   %put NOTE- Element of type macros generated from the file "mf_trimstr.sas" will be deleted;
   %put NOTE- ;
   ,"MF_TRIMSTR                                                      "
   %put NOTE- Element of type macros generated from the file "mf_uid.sas" will be deleted;
   %put NOTE- ;
   ,"MF_UID                                                          "
   %put NOTE- Element of type macros generated from the file "mf_verifymacvars.sas" will be deleted;
   %put NOTE- ;
   ,"MF_VERIFYMACVARS                                                "
   %put NOTE- Element of type macros generated from the file "mf_wordsinstr1andstr2.sas" will be deleted;
   %put NOTE- ;
   ,"MF_WORDSINSTR1ANDSTR2                                           "
   %put NOTE- Element of type macros generated from the file "mf_wordsinstr1butnotstr2.sas" will be deleted;
   %put NOTE- ;
   ,"MF_WORDSINSTR1BUTNOTSTR2                                        "
   %put NOTE- Element of type macros generated from the file "mf_writefile.sas" will be deleted;
   %put NOTE- ;
   ,"MF_WRITEFILE                                                    "
   %put NOTE- Element of type macros generated from the file "mp_abort.sas" will be deleted;
   %put NOTE- ;
   ,"MP_ABORT                                                        "
   %put NOTE- Element of type macros generated from the file "mp_aligndecimal.sas" will be deleted;
   %put NOTE- ;
   ,"MP_ALIGNDECIMAL                                                 "
   %put NOTE- Element of type macros generated from the file "mp_appendfile.sas" will be deleted;
   %put NOTE- ;
   ,"MP_APPENDFILE                                                   "
   %put NOTE- Element of type macros generated from the file "mp_applyformats.sas" will be deleted;
   %put NOTE- ;
   ,"MP_APPLYFORMATS                                                 "
   %put NOTE- Element of type macros generated from the file "mp_assert.sas" will be deleted;
   %put NOTE- ;
   ,"MP_ASSERT                                                       "
   %put NOTE- Element of type macros generated from the file "mp_assertcols.sas" will be deleted;
   %put NOTE- ;
   ,"MP_ASSERTCOLS                                                   "
   %put NOTE- Element of type macros generated from the file "mp_assertcolvals.sas" will be deleted;
   %put NOTE- ;
   ,"MP_ASSERTCOLVALS                                                "
   %put NOTE- Element of type macros generated from the file "mp_assertdsobs.sas" will be deleted;
   %put NOTE- ;
   ,"MP_ASSERTDSOBS                                                  "
   %put NOTE- Element of type macros generated from the file "mp_assertscope.sas" will be deleted;
   %put NOTE- ;
   ,"MP_ASSERTSCOPE                                                  "
   %put NOTE- Element of type macros generated from the file "mp_base64copy.sas" will be deleted;
   %put NOTE- ;
   ,"MP_BASE64COPY                                                   "
   %put NOTE- Element of type macros generated from the file "mp_binarycopy.sas" will be deleted;
   %put NOTE- ;
   ,"MP_BINARYCOPY                                                   "
   %put NOTE- Element of type macros generated from the file "mp_chop.sas" will be deleted;
   %put NOTE- ;
   ,"MP_CHOP                                                         "
   %put NOTE- Element of type macros generated from the file "mp_cleancsv.sas" will be deleted;
   %put NOTE- ;
   ,"MP_CLEANCSV                                                     "
   %put NOTE- Element of type macros generated from the file "mp_cntlout.sas" will be deleted;
   %put NOTE- ;
   ,"MP_CNTLOUT                                                      "
   %put NOTE- Element of type macros generated from the file "mp_copyfolder.sas" will be deleted;
   %put NOTE- ;
   ,"MP_COPYFOLDER                                                   "
   %put NOTE- Element of type macros generated from the file "mp_coretable.sas" will be deleted;
   %put NOTE- ;
   ,"MP_CORETABLE                                                    "
   %put NOTE- Element of type macros generated from the file "mp_createconstraints.sas" will be deleted;
   %put NOTE- ;
   ,"MP_CREATECONSTRAINTS                                            "
   %put NOTE- Element of type macros generated from the file "mp_createwebservice.sas" will be deleted;
   %put NOTE- ;
   ,"MP_CREATEWEBSERVICE                                             "
   %put NOTE- Element of type macros generated from the file "mp_csv2ds.sas" will be deleted;
   %put NOTE- ;
   ,"MP_CSV2DS                                                       "
   %put NOTE- Element of type macros generated from the file "mp_deleteconstraints.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DELETECONSTRAINTS                                            "
   %put NOTE- Element of type macros generated from the file "mp_deletefolder.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DELETEFOLDER                                                 "
   %put NOTE- Element of type macros generated from the file "mp_dictionary.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DICTIONARY                                                   "
   %put NOTE- Element of type macros generated from the file "mp_dirlist.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DIRLIST                                                      "
   %put NOTE- Element of type macros generated from the file "mp_distinctfmtvalues.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DISTINCTFMTVALUES                                            "
   %put NOTE- Element of type macros generated from the file "mp_dropmembers.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DROPMEMBERS                                                  "
   %put NOTE- Element of type macros generated from the file "mp_ds2cards.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DS2CARDS                                                     "
   %put NOTE- Element of type macros generated from the file "mp_ds2csv.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DS2CSV                                                       "
   %put NOTE- Element of type macros generated from the file "mp_ds2ddl.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DS2DDL                                                       "
   %put NOTE- Element of type macros generated from the file "mp_ds2fmtds.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DS2FMTDS                                                     "
   %put NOTE- Element of type macros generated from the file "mp_ds2inserts.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DS2INSERTS                                                   "
   %put NOTE- Element of type macros generated from the file "mp_ds2md.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DS2MD                                                        "
   %put NOTE- Element of type macros generated from the file "mp_ds2squeeze.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DS2SQUEEZE                                                   "
   %put NOTE- Element of type macros generated from the file "mp_dsmeta.sas" will be deleted;
   %put NOTE- ;
   ,"MP_DSMETA                                                       "
   %put NOTE- Element of type macros generated from the file "mp_filtercheck.sas" will be deleted;
   %put NOTE- ;
   ,"MP_FILTERCHECK                                                  "
   %put NOTE- Element of type macros generated from the file "mp_filtergenerate.sas" will be deleted;
   %put NOTE- ;
   ,"MP_FILTERGENERATE                                               "
   %put NOTE- Element of type macros generated from the file "mp_filterstore.sas" will be deleted;
   %put NOTE- ;
   ,"MP_FILTERSTORE                                                  "
   %put NOTE- Element of type macros generated from the file "mp_filtervalidate.sas" will be deleted;
   %put NOTE- ;
   ,"MP_FILTERVALIDATE                                               "
   %put NOTE- Element of type macros generated from the file "mp_getcols.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GETCOLS                                                      "
   %put NOTE- Element of type macros generated from the file "mp_getconstraints.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GETCONSTRAINTS                                               "
   %put NOTE- Element of type macros generated from the file "mp_getdbml.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GETDBML                                                      "
   %put NOTE- Element of type macros generated from the file "mp_getddl.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GETDDL                                                       "
   %put NOTE- Element of type macros generated from the file "mp_getformats.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GETFORMATS                                                   "
   %put NOTE- Element of type macros generated from the file "mp_getmaxvarlengths.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GETMAXVARLENGTHS                                             "
   %put NOTE- Element of type macros generated from the file "mp_getpk.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GETPK                                                        "
   %put NOTE- Element of type macros generated from the file "mp_gitadd.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GITADD                                                       "
   %put NOTE- Element of type macros generated from the file "mp_gitlog.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GITLOG                                                       "
   %put NOTE- Element of type macros generated from the file "mp_gitreleaseinfo.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GITRELEASEINFO                                               "
   %put NOTE- Element of type macros generated from the file "mp_gitstatus.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GITSTATUS                                                    "
   %put NOTE- Element of type macros generated from the file "mp_gsubfile.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GSUBFILE                                                     "
   %put NOTE- Element of type macros generated from the file "mp_guesspk.sas" will be deleted;
   %put NOTE- ;
   ,"MP_GUESSPK                                                      "
   %put NOTE- Element of type macros generated from the file "mp_hashdataset.sas" will be deleted;
   %put NOTE- ;
   ,"MP_HASHDATASET                                                  "
   %put NOTE- Element of type macros generated from the file "mp_hashdirectory.sas" will be deleted;
   %put NOTE- ;
   ,"MP_HASHDIRECTORY                                                "
   %put NOTE- Element of type macros generated from the file "mp_include.sas" will be deleted;
   %put NOTE- ;
   ,"MP_INCLUDE                                                      "
   %put NOTE- Element of type macros generated from the file "mp_init.sas" will be deleted;
   %put NOTE- ;
   ,"MP_INIT                                                         "
   %put NOTE- Element of type macros generated from the file "mp_jsonout.sas" will be deleted;
   %put NOTE- ;
   ,"MP_JSONOUT                                                      "
   %put NOTE- Element of type macros generated from the file "mp_lib2cards.sas" will be deleted;
   %put NOTE- ;
   ,"MP_LIB2CARDS                                                    "
   %put NOTE- Element of type macros generated from the file "mp_lib2inserts.sas" will be deleted;
   %put NOTE- ;
   ,"MP_LIB2INSERTS                                                  "
   %put NOTE- Element of type macros generated from the file "mp_loadformat.sas" will be deleted;
   %put NOTE- ;
   ,"MP_LOADFORMAT                                                   "
   %put NOTE- Element of type macros generated from the file "mp_lockanytable.sas" will be deleted;
   %put NOTE- ;
   ,"MP_LOCKANYTABLE                                                 "
   %put NOTE- Element of type macros generated from the file "mp_lockfilecheck.sas" will be deleted;
   %put NOTE- ;
   ,"MP_LOCKFILECHECK                                                "
   %put NOTE- Element of type macros generated from the file "mp_makedata.sas" will be deleted;
   %put NOTE- ;
   ,"MP_MAKEDATA                                                     "
   %put NOTE- Element of type macros generated from the file "mp_md5.sas" will be deleted;
   %put NOTE- ;
   ,"MP_MD5                                                          "
   %put NOTE- Element of type macros generated from the file "mp_perflog.sas" will be deleted;
   %put NOTE- ;
   ,"MP_PERFLOG                                                      "
   %put NOTE- Element of type macros generated from the file "mp_prevobs.sas" will be deleted;
   %put NOTE- ;
   ,"MP_PREVOBS                                                      "
   %put NOTE- Element of type macros generated from the file "mp_recursivejoin.sas" will be deleted;
   %put NOTE- ;
   ,"MP_RECURSIVEJOIN                                                "
   %put NOTE- Element of type macros generated from the file "mp_replace.sas" will be deleted;
   %put NOTE- ;
   ,"MP_REPLACE                                                      "
   %put NOTE- Element of type macros generated from the file "mp_reseterror.sas" will be deleted;
   %put NOTE- ;
   ,"MP_RESETERROR                                                   "
   %put NOTE- Element of type macros generated from the file "mp_resetoption.sas" will be deleted;
   %put NOTE- ;
   ,"MP_RESETOPTION                                                  "
   %put NOTE- Element of type macros generated from the file "mp_retainedkey.sas" will be deleted;
   %put NOTE- ;
   ,"MP_RETAINEDKEY                                                  "
   %put NOTE- Element of type macros generated from the file "mp_rowhash.sas" will be deleted;
   %put NOTE- ;
   ,"MP_ROWHASH                                                      "
   %put NOTE- Element of type macros generated from the file "mp_runddl.sas" will be deleted;
   %put NOTE- ;
   ,"MP_RUNDDL                                                       "
   %put NOTE- Element of type macros generated from the file "mp_searchcols.sas" will be deleted;
   %put NOTE- ;
   ,"MP_SEARCHCOLS                                                   "
   %put NOTE- Element of type macros generated from the file "mp_searchdata.sas" will be deleted;
   %put NOTE- ;
   ,"MP_SEARCHDATA                                                   "
   %put NOTE- Element of type macros generated from the file "mp_setkeyvalue.sas" will be deleted;
   %put NOTE- ;
   ,"MP_SETKEYVALUE                                                  "
   %put NOTE- Element of type macros generated from the file "mp_sortinplace.sas" will be deleted;
   %put NOTE- ;
   ,"MP_SORTINPLACE                                                  "
   %put NOTE- Element of type macros generated from the file "mp_stackdiffs.sas" will be deleted;
   %put NOTE- ;
   ,"MP_STACKDIFFS                                                   "
   %put NOTE- Element of type macros generated from the file "mp_storediffs.sas" will be deleted;
   %put NOTE- ;
   ,"MP_STOREDIFFS                                                   "
   %put NOTE- Element of type macros generated from the file "mp_stprequests.sas" will be deleted;
   %put NOTE- ;
   ,"MP_STPREQUESTS                                                  "
   %put NOTE- Element of type macros generated from the file "mp_streamfile.sas" will be deleted;
   %put NOTE- ;
   ,"MP_STREAMFILE                                                   "
   %put NOTE- Element of type macros generated from the file "mp_stripdiffs.sas" will be deleted;
   %put NOTE- ;
   ,"MP_STRIPDIFFS                                                   "
   %put NOTE- Element of type macros generated from the file "mp_testjob.sas" will be deleted;
   %put NOTE- ;
   ,"MP_TESTJOB                                                      "
   %put NOTE- Element of type macros generated from the file "mp_testservice.sas" will be deleted;
   %put NOTE- ;
   ,"MP_TESTSERVICE                                                  "
   %put NOTE- Element of type macros generated from the file "mp_testwritespeedlibrary.sas" will be deleted;
   %put NOTE- ;
   ,"MP_TESTWRITESPEEDLIBRARY                                        "
   %put NOTE- Element of type macros generated from the file "mp_tree.sas" will be deleted;
   %put NOTE- ;
   ,"MP_TREE                                                         "
   %put NOTE- Element of type macros generated from the file "mp_unzip.sas" will be deleted;
   %put NOTE- ;
   ,"MP_UNZIP                                                        "
   %put NOTE- Element of type macros generated from the file "mp_updatevarlength.sas" will be deleted;
   %put NOTE- ;
   ,"MP_UPDATEVARLENGTH                                              "
   %put NOTE- Element of type macros generated from the file "mp_validatecol.sas" will be deleted;
   %put NOTE- ;
   ,"MP_VALIDATECOL                                                  "
   %put NOTE- Element of type macros generated from the file "mp_wait4file.sas" will be deleted;
   %put NOTE- ;
   ,"MP_WAIT4FILE                                                    "
   %put NOTE- Element of type macros generated from the file "mp_webin.sas" will be deleted;
   %put NOTE- ;
   ,"MP_WEBIN                                                        "
   %put NOTE- Element of type macros generated from the file "mp_zip.sas" will be deleted;
   %put NOTE- ;
   ,"MP_ZIP                                                          "
   %put NOTE- Element of type macros generated from the file "mddl_dc_difftable.sas" will be deleted;
   %put NOTE- ;
   ,"MDDL_DC_DIFFTABLE                                               "
   %put NOTE- Element of type macros generated from the file "mddl_dc_filterdetail.sas" will be deleted;
   %put NOTE- ;
   ,"MDDL_DC_FILTERDETAIL                                            "
   %put NOTE- Element of type macros generated from the file "mddl_dc_filtersummary.sas" will be deleted;
   %put NOTE- ;
   ,"MDDL_DC_FILTERSUMMARY                                           "
   %put NOTE- Element of type macros generated from the file "mddl_dc_locktable.sas" will be deleted;
   %put NOTE- ;
   ,"MDDL_DC_LOCKTABLE                                               "
   %put NOTE- Element of type macros generated from the file "mddl_dc_maxkeytable.sas" will be deleted;
   %put NOTE- ;
   ,"MDDL_DC_MAXKEYTABLE                                             "
   %put NOTE- Element of type macros generated from the file "mddl_sas_cntlout.sas" will be deleted;
   %put NOTE- ;
   ,"MDDL_SAS_CNTLOUT                                                "
   %put NOTE- Element of type macros generated from the file "mcf_getfmttype.sas" will be deleted;
   %put NOTE- ;
   ,"MCF_GETFMTTYPE                                                  "
   %put NOTE- Element of type macros generated from the file "mcf_init.sas" will be deleted;
   %put NOTE- ;
   ,"MCF_INIT                                                        "
   %put NOTE- Element of type macros generated from the file "mcf_length.sas" will be deleted;
   %put NOTE- ;
   ,"MCF_LENGTH                                                      "
   %put NOTE- Element of type macros generated from the file "mcf_string2file.sas" will be deleted;
   %put NOTE- ;
   ,"MCF_STRING2FILE                                                 "
   %put NOTE- Element of type macros generated from the file "ml_gsubfile.sas" will be deleted;
   %put NOTE- ;
   ,"ML_GSUBFILE                                                     "
   %put NOTE- Element of type macros generated from the file "ml_json.sas" will be deleted;
   %put NOTE- ;
   ,"ML_JSON                                                         "
   %put NOTE- Element of type macros generated from the file "mm_adduser2group.sas" will be deleted;
   %put NOTE- ;
   ,"MM_ADDUSER2GROUP                                                "
   %put NOTE- Element of type macros generated from the file "mm_assigndirectlib.sas" will be deleted;
   %put NOTE- ;
   ,"MM_ASSIGNDIRECTLIB                                              "
   %put NOTE- Element of type macros generated from the file "mm_assignlib.sas" will be deleted;
   %put NOTE- ;
   ,"MM_ASSIGNLIB                                                    "
   %put NOTE- Element of type macros generated from the file "mm_createapplication.sas" will be deleted;
   %put NOTE- ;
   ,"MM_CREATEAPPLICATION                                            "
   %put NOTE- Element of type macros generated from the file "mm_createdataset.sas" will be deleted;
   %put NOTE- ;
   ,"MM_CREATEDATASET                                                "
   %put NOTE- Element of type macros generated from the file "mm_createdocument.sas" will be deleted;
   %put NOTE- ;
   ,"MM_CREATEDOCUMENT                                               "
   %put NOTE- Element of type macros generated from the file "mm_createfolder.sas" will be deleted;
   %put NOTE- ;
   ,"MM_CREATEFOLDER                                                 "
   %put NOTE- Element of type macros generated from the file "mm_createlibrary.sas" will be deleted;
   %put NOTE- ;
   ,"MM_CREATELIBRARY                                                "
   %put NOTE- Element of type macros generated from the file "mm_createstp.sas" will be deleted;
   %put NOTE- ;
   ,"MM_CREATESTP                                                    "
   %put NOTE- Element of type macros generated from the file "mm_createwebservice.sas" will be deleted;
   %put NOTE- ;
   ,"MM_CREATEWEBSERVICE                                             "
   %put NOTE- Element of type macros generated from the file "mm_deletedocument.sas" will be deleted;
   %put NOTE- ;
   ,"MM_DELETEDOCUMENT                                               "
   %put NOTE- Element of type macros generated from the file "mm_deletelibrary.sas" will be deleted;
   %put NOTE- ;
   ,"MM_DELETELIBRARY                                                "
   %put NOTE- Element of type macros generated from the file "mm_deletestp.sas" will be deleted;
   %put NOTE- ;
   ,"MM_DELETESTP                                                    "
   %put NOTE- Element of type macros generated from the file "mm_getauthinfo.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETAUTHINFO                                                  "
   %put NOTE- Element of type macros generated from the file "mm_getcols.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETCOLS                                                      "
   %put NOTE- Element of type macros generated from the file "mm_getdetails.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETDETAILS                                                   "
   %put NOTE- Element of type macros generated from the file "mm_getdirectories.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETDIRECTORIES                                               "
   %put NOTE- Element of type macros generated from the file "mm_getdocument.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETDOCUMENT                                                  "
   %put NOTE- Element of type macros generated from the file "mm_getfoldermembers.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETFOLDERMEMBERS                                             "
   %put NOTE- Element of type macros generated from the file "mm_getfoldertree.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETFOLDERTREE                                                "
   %put NOTE- Element of type macros generated from the file "mm_getgroupmembers.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETGROUPMEMBERS                                              "
   %put NOTE- Element of type macros generated from the file "mm_getgroups.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETGROUPS                                                    "
   %put NOTE- Element of type macros generated from the file "mm_getlibmetadiffs.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETLIBMETADIFFS                                              "
   %put NOTE- Element of type macros generated from the file "mm_getlibs.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETLIBS                                                      "
   %put NOTE- Element of type macros generated from the file "mm_getobjects.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETOBJECTS                                                   "
   %put NOTE- Element of type macros generated from the file "mm_getpublictypes.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETPUBLICTYPES                                               "
   %put NOTE- Element of type macros generated from the file "mm_getrepos.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETREPOS                                                     "
   %put NOTE- Element of type macros generated from the file "mm_getroles.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETROLES                                                     "
   %put NOTE- Element of type macros generated from the file "mm_getservercontexts.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETSERVERCONTEXTS                                            "
   %put NOTE- Element of type macros generated from the file "mm_getstpcode.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETSTPCODE                                                   "
   %put NOTE- Element of type macros generated from the file "mm_getstpinfo.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETSTPINFO                                                   "
   %put NOTE- Element of type macros generated from the file "mm_getstps.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETSTPS                                                      "
   %put NOTE- Element of type macros generated from the file "mm_gettableid.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETTABLEID                                                   "
   %put NOTE- Element of type macros generated from the file "mm_gettables.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETTABLES                                                    "
   %put NOTE- Element of type macros generated from the file "mm_gettree.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETTREE                                                      "
   %put NOTE- Element of type macros generated from the file "mm_gettypes.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETTYPES                                                     "
   %put NOTE- Element of type macros generated from the file "mm_getusers.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETUSERS                                                     "
   %put NOTE- Element of type macros generated from the file "mm_getwebappsrvprops.sas" will be deleted;
   %put NOTE- ;
   ,"MM_GETWEBAPPSRVPROPS                                            "
   %put NOTE- Element of type macros generated from the file "mm_spkexport.sas" will be deleted;
   %put NOTE- ;
   ,"MM_SPKEXPORT                                                    "
   %put NOTE- Element of type macros generated from the file "mm_tree.sas" will be deleted;
   %put NOTE- ;
   ,"MM_TREE                                                         "
   %put NOTE- Element of type macros generated from the file "mm_updateappextension.sas" will be deleted;
   %put NOTE- ;
   ,"MM_UPDATEAPPEXTENSION                                           "
   %put NOTE- Element of type macros generated from the file "mm_updatedocument.sas" will be deleted;
   %put NOTE- ;
   ,"MM_UPDATEDOCUMENT                                               "
   %put NOTE- Element of type macros generated from the file "mm_updatestpservertype.sas" will be deleted;
   %put NOTE- ;
   ,"MM_UPDATESTPSERVERTYPE                                          "
   %put NOTE- Element of type macros generated from the file "mm_updatestpsourcecode.sas" will be deleted;
   %put NOTE- ;
   ,"MM_UPDATESTPSOURCECODE                                          "
   %put NOTE- Element of type macros generated from the file "mm_webout.sas" will be deleted;
   %put NOTE- ;
   ,"MM_WEBOUT                                                       "
   %put NOTE- Element of type macros generated from the file "mmx_createmetafolder.sas" will be deleted;
   %put NOTE- ;
   ,"MMX_CREATEMETAFOLDER                                            "
   %put NOTE- Element of type macros generated from the file "mmx_deletemetafolder.sas" will be deleted;
   %put NOTE- ;
   ,"MMX_DELETEMETAFOLDER                                            "
   %put NOTE- Element of type macros generated from the file "mmx_spkexport.sas" will be deleted;
   %put NOTE- ;
   ,"MMX_SPKEXPORT                                                   "
   %put NOTE- Element of type macros generated from the file "mfs_httpheader.sas" will be deleted;
   %put NOTE- ;
   ,"MFS_HTTPHEADER                                                  "
   %put NOTE- Element of type macros generated from the file "ms_adduser2group.sas" will be deleted;
   %put NOTE- ;
   ,"MS_ADDUSER2GROUP                                                "
   %put NOTE- Element of type macros generated from the file "ms_createfile.sas" will be deleted;
   %put NOTE- ;
   ,"MS_CREATEFILE                                                   "
   %put NOTE- Element of type macros generated from the file "ms_creategroup.sas" will be deleted;
   %put NOTE- ;
   ,"MS_CREATEGROUP                                                  "
   %put NOTE- Element of type macros generated from the file "ms_createuser.sas" will be deleted;
   %put NOTE- ;
   ,"MS_CREATEUSER                                                   "
   %put NOTE- Element of type macros generated from the file "ms_createwebservice.sas" will be deleted;
   %put NOTE- ;
   ,"MS_CREATEWEBSERVICE                                             "
   %put NOTE- Element of type macros generated from the file "ms_deletefile.sas" will be deleted;
   %put NOTE- ;
   ,"MS_DELETEFILE                                                   "
   %put NOTE- Element of type macros generated from the file "ms_getfile.sas" will be deleted;
   %put NOTE- ;
   ,"MS_GETFILE                                                      "
   %put NOTE- Element of type macros generated from the file "ms_getgroups.sas" will be deleted;
   %put NOTE- ;
   ,"MS_GETGROUPS                                                    "
   %put NOTE- Element of type macros generated from the file "ms_getusers.sas" will be deleted;
   %put NOTE- ;
   ,"MS_GETUSERS                                                     "
   %put NOTE- Element of type macros generated from the file "ms_runstp.sas" will be deleted;
   %put NOTE- ;
   ,"MS_RUNSTP                                                       "
   %put NOTE- Element of type macros generated from the file "ms_testservice.sas" will be deleted;
   %put NOTE- ;
   ,"MS_TESTSERVICE                                                  "
   %put NOTE- Element of type macros generated from the file "ms_triggerstp.sas" will be deleted;
   %put NOTE- ;
   ,"MS_TRIGGERSTP                                                   "
   %put NOTE- Element of type macros generated from the file "ms_webout.sas" will be deleted;
   %put NOTE- ;
   ,"MS_WEBOUT                                                       "
   %put NOTE- Element of type macros generated from the file "mfv_existfile.sas" will be deleted;
   %put NOTE- ;
   ,"MFV_EXISTFILE                                                   "
   %put NOTE- Element of type macros generated from the file "mfv_existfolder.sas" will be deleted;
   %put NOTE- ;
   ,"MFV_EXISTFOLDER                                                 "
   %put NOTE- Element of type macros generated from the file "mfv_existsashdat.sas" will be deleted;
   %put NOTE- ;
   ,"MFV_EXISTSASHDAT                                                "
   %put NOTE- Element of type macros generated from the file "mfv_getcaslib.sas" will be deleted;
   %put NOTE- ;
   ,"MFV_GETCASLIB                                                   "
   %put NOTE- Element of type macros generated from the file "mfv_getfolderpath.sas" will be deleted;
   %put NOTE- ;
   ,"MFV_GETFOLDERPATH                                               "
   %put NOTE- Element of type macros generated from the file "mfv_getpathuri.sas" will be deleted;
   %put NOTE- ;
   ,"MFV_GETPATHURI                                                  "
   %put NOTE- Element of type macros generated from the file "mv_castabload.sas" will be deleted;
   %put NOTE- ;
   ,"MV_CASTABLOAD                                                   "
   %put NOTE- Element of type macros generated from the file "mv_castabsave.sas" will be deleted;
   %put NOTE- ;
   ,"MV_CASTABSAVE                                                   "
   %put NOTE- Element of type macros generated from the file "mv_createfile.sas" will be deleted;
   %put NOTE- ;
   ,"MV_CREATEFILE                                                   "
   %put NOTE- Element of type macros generated from the file "mv_createfolder.sas" will be deleted;
   %put NOTE- ;
   ,"MV_CREATEFOLDER                                                 "
   %put NOTE- Element of type macros generated from the file "mv_createjob.sas" will be deleted;
   %put NOTE- ;
   ,"MV_CREATEJOB                                                    "
   %put NOTE- Element of type macros generated from the file "mv_createwebservice.sas" will be deleted;
   %put NOTE- ;
   ,"MV_CREATEWEBSERVICE                                             "
   %put NOTE- Element of type macros generated from the file "mv_deletefoldermember.sas" will be deleted;
   %put NOTE- ;
   ,"MV_DELETEFOLDERMEMBER                                           "
   %put NOTE- Element of type macros generated from the file "mv_deletejes.sas" will be deleted;
   %put NOTE- ;
   ,"MV_DELETEJES                                                    "
   %put NOTE- Element of type macros generated from the file "mv_deleteviyafolder.sas" will be deleted;
   %put NOTE- ;
   ,"MV_DELETEVIYAFOLDER                                             "
   %put NOTE- Element of type macros generated from the file "mv_getclients.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETCLIENTS                                                   "
   %put NOTE- Element of type macros generated from the file "mv_getfoldermembers.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETFOLDERMEMBERS                                             "
   %put NOTE- Element of type macros generated from the file "mv_getgroupmembers.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETGROUPMEMBERS                                              "
   %put NOTE- Element of type macros generated from the file "mv_getgroups.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETGROUPS                                                    "
   %put NOTE- Element of type macros generated from the file "mv_getjobcode.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETJOBCODE                                                   "
   %put NOTE- Element of type macros generated from the file "mv_getjoblog.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETJOBLOG                                                    "
   %put NOTE- Element of type macros generated from the file "mv_getjobresult.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETJOBRESULT                                                 "
   %put NOTE- Element of type macros generated from the file "mv_getjobstate.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETJOBSTATE                                                  "
   %put NOTE- Element of type macros generated from the file "mv_getusergroups.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETUSERGROUPS                                                "
   %put NOTE- Element of type macros generated from the file "mv_getusers.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETUSERS                                                     "
   %put NOTE- Element of type macros generated from the file "mv_getviyafileextparms.sas" will be deleted;
   %put NOTE- ;
   ,"MV_GETVIYAFILEEXTPARMS                                          "
   %put NOTE- Element of type macros generated from the file "mv_jobexecute.sas" will be deleted;
   %put NOTE- ;
   ,"MV_JOBEXECUTE                                                   "
   %put NOTE- Element of type macros generated from the file "mv_jobflow.sas" will be deleted;
   %put NOTE- ;
   ,"MV_JOBFLOW                                                      "
   %put NOTE- Element of type macros generated from the file "mv_jobwaitfor.sas" will be deleted;
   %put NOTE- ;
   ,"MV_JOBWAITFOR                                                   "
   %put NOTE- Element of type macros generated from the file "mv_registerclient.sas" will be deleted;
   %put NOTE- ;
   ,"MV_REGISTERCLIENT                                               "
   %put NOTE- Element of type macros generated from the file "mv_tokenauth.sas" will be deleted;
   %put NOTE- ;
   ,"MV_TOKENAUTH                                                    "
   %put NOTE- Element of type macros generated from the file "mv_tokenrefresh.sas" will be deleted;
   %put NOTE- ;
   ,"MV_TOKENREFRESH                                                 "
   %put NOTE- Element of type macros generated from the file "mv_webout.sas" will be deleted;
   %put NOTE- ;
   ,"MV_WEBOUT                                                       "
   %put NOTE- Element of type macros generated from the file "mx_append2pgm.sas" will be deleted;
   %put NOTE- ;
   ,"MX_APPEND2PGM                                                   "
   %put NOTE- Element of type macros generated from the file "mx_createjob.sas" will be deleted;
   %put NOTE- ;
   ,"MX_CREATEJOB                                                    "
   %put NOTE- Element of type macros generated from the file "mx_createwebservice.sas" will be deleted;
   %put NOTE- ;
   ,"MX_CREATEWEBSERVICE                                             "
   %put NOTE- Element of type macros generated from the file "mx_getcode.sas" will be deleted;
   %put NOTE- ;
   ,"MX_GETCODE                                                      "
   %put NOTE- Element of type macros generated from the file "mx_getgroups.sas" will be deleted;
   %put NOTE- ;
   ,"MX_GETGROUPS                                                    "
   %put NOTE- Element of type macros generated from the file "mx_testservice.sas" will be deleted;
   %put NOTE- ;
   ,"MX_TESTSERVICE                                                  "
  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"
  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'SASJSCOREFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.SASjsCorefcmp.package;
quit;

proc fcmp outlib = work.SASjsCorefcmp.packagemeta;
deletefunc SASjsCoreMETA;
quit;

options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.sasjscorefcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc SQL noprint;
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                                         
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#sasjscore(4.68.3)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#SASjsCore(4.68.3)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  
%put NOTE: Unloading package SASjsCore, version 4.68.3, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;
/* unload.sas end */
